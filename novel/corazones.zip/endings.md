# Finales

## Final documentado: "Para Siempre Juntos" (Ruta Harem) — FINAL VERDADERO

- Requisito: Opción E en Cap. 21 (condición: diferencia de puntos ≤2).
- Logros oficiales desbloqueados (bloque final Cap. 15H):
  - "Familia Culinaria Eterna" — completar la ruta harem hasta el final.
  - "Legado Gastronómico" — ver el impacto culinario a largo plazo.
  - "Amor Multiplicado" — demostrar que el amor culinario crece cuando se comparte.
  - "Milagros Cotidianos" — encontrar lo extraordinario en platos ordinarios.
  - "Para Siempre Juntos" — **final verdadero desbloqueado**.
  - "Maestro de Sakura-machi" — transformar completamente el pueblo.
  - "Academia Internacional" — crear legado educativo gastronómico.
- Estadísticas finales: 20 años; 4 hijas criadas; 200+ restaurantes inspirados; 50,000+ visitantes anuales; 30+ países; 3 libros culinarios; 2 generaciones de chefs formadas; "Platos perfectos creados: Infinitos".
- Cierre del documento: "FIN DE LA RUTA HAREM / FIN DE CORAZONES EN EBULLICIÓN" + despedida al jugador ("Que encuentres tu propia versión de Sakura-machi").

## Finales de las Rutas Individuales (A–D)

- En el texto original: **NOT STATED.** Este documento no contiene los capítulos de las rutas individuales después de la elección. Solo se sabe que:
  - Existiría un Cap. 8 "Nuevo Equilibrio" por rama (bloque final Cap. 21).
  - La mecánica sería "+5 a heroína elegida, reset otras a 0".
- **Actualización (14/09/2026):** la Ruta Individual C (**Ruta Mika**) fue definida por el autor — ver abajo. Las rutas A (Saki), B (Ren) y D (Yuki) siguen `NOT STATED`; cualquier contenido suyo seguiría siendo material nuevo.

## Final 2: "El Corazón Auténtico" (Ruta Mika) — canon de autor

> `USER-CANON (autor)` — diseño profundo completo en `routes/ruta-mika.md`. Final alternativo y excluyente con "Para Siempre Juntos" (Ruta Harem), que sigue siendo el **final verdadero** del juego.

- **Requisito:** Opción C en la bifurcación del Cap. 21 (ayudar a Mika frente a Kenji (productor)). Sin requisito de puntos (la condición ≤2 solo aplica a la Opción E).
- **Ganadora:** Mika Nakamura (23 años, `USER-CANON`) — romance exclusivo Hiroshi–Mika.
- **Rasgo distintivo (decisión de autor):** Yuki, Ren y Saki **no se alejan** — permanecen en Sakura-machi como familia elegida y apoyan a Mika mientras desarrolla su historia (reconstrucción de su identidad, relación sana con la creación de contenido, duelo por su hermana).
- **Estructura completa (guion desarrollado):** Caps. 8M–14M — **7 capítulos, 38 escenas de trama** (+1 post-créditos), **12 escenas opcionales** (O1–O12) y **15 viñetas de epílogo post-créditos** (E1–E15), 6 elecciones, sin puntuación interna (el sistema de puntos termina al entrar a la ruta, decisión de autor). **~52,700 palabras ≈ 9–10 h de juego.** Guion completo en `routes/ruta-mika/` (un archivo por capítulo + `escenas-opcionales.md` + `epilogo-opcional.md`); diseño de producción en `routes/ruta-mika.md` (17 CGs, explícito desde 11M.4, cierre de cabos sueltos). **5 escenas explícitas:** 11M.4, **13M.5 (concepción de Hina)**, 14M.2 + E13 y E15 (bonus).
- **Escenas de sexo explícitas (regla de autor, 14/09/2026):** mínimo 2 por final independiente, escritas sin elipsis — el premio al jugador. Esta ruta incluye **3**: 11M.4 (primera noche, ~60–90 líneas), 13M.5 (noche del compromiso, ~60 líneas) y 14M.2 (noche de bodas, ~40 líneas). La Ruta Harem queda intacta (canon del texto original).
- **Final único (decisión de autor, 14/09/2026):** solo existe el **Final Feliz "El Corazón Auténtico"** — no hay finales neutros ni malos en esta ruta (el Final Neutro "La Cámara Amiga" fue **eliminado** del diseño). Toda partida que entre por la Opción C termina en boda. Las elecciones moldean escenas y CGs, nunca el desenlace.
- **Guion desarrollado:** los capítulos narrativos completos (texto de juego) viven en `routes/ruta-mika/` (un archivo por capítulo).
- **Cierre de cabos en esta rama:** hermana de Mika (enfermedad larga, DA-M05), pago de las amenazas de los cuatro antagonistas, parentesco Yamamoto de Saki, arcos de Yuki/Matsui, Ren/Emi y la culpa de Hiroshi. Detalle: tabla en `routes/ruta-mika.md` §5.
- **Logro sugerido:** "El Corazón Auténtico" — final desbloqueado (`PROPUESTO`).

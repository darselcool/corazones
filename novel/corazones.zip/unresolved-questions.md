# Preguntas no resueltas (para futuros capítulos)

Preguntas que un capítulo nuevo podría responder, con su estado canónico actual.

1. ¿Qué compitió exactamente en Yuki y qué pasó en su colapso público? — `UNRESOLVED` (mysteries 001).
2. ¿Murió la madre de Yuki en un accidente? ¿Dijo Matsui la verdad, mintió o distorsionó? — `UNRESOLVED` (mysteries 002).
3. ¿Qué le pasó a la hermana de Mika? ¿Murió? ¿Cuándo? — `UNRESOLVED` (mysteries 003).
4. ¿Qué accidente mató al abuelo de Ren? ¿Hubo negligencia real? ¿Quién es Emi exactamente? — `UNRESOLVED` (mysteries 004).
5. ¿Qué acuerdo tenía Saki con los desarrolladores y qué amenaza legal persiste? — `PARTIALLY RESOLVED` (mysteries 005).
6. ¿Saki es pariente de la familia Yamamoto del restaurante original? — `THEORY` (mysteries 006).
7. ¿Regresarán Watanabe, Emi, Kenji o Matsui ("esto no ha terminado")? — `UNRESOLVED` (mysteries 007).
8. ¿Cómo y cuándo murió Kenji, el mentor de Hiroshi? — `UNRESOLVED` (mysteries 008).
9. ¿Cuál fue "la primera crisis" de Saki en el restaurante del pueblo (13H.6)? — `UNRESOLVED` (mysteries 009).
10. ¿Por qué el documental se titula "La Familia Nakamura"? — `THEORY` (mysteries 010).
11. ¿Quién reemplazó a Hiroshi en su restaurante estrella? — `UNRESOLVED` (mysteries 011).
12. ¿Por qué los nombres finales de las hijas difieren de los elegidos en 14H.6? — `INCONSISTENCIA` (contradictions 003).
13. ¿Cómo conoció el pueblo a las parejas de las hijas ("pruebas de compatibilidad")? — `NOT STATED` (15H.7).
14. ¿Qué hace la "Asociación de Chefs de Japón" además de la distinción de 15H.3? — `NOT STATED`.
15. Edades exactas de Hiroshi, Yuki y Mika — `NOT STATED`.
16. Nombre de pila de la Señora Tanaka — `NOT STATED`.
17. ¿Qué relación hay entre el Dr. Tanaka (fertilidad) y la Señora Tanaka? — `NOT STATED`.
18. ¿Dónde vivía Yuki entre los caps. 2.5 y 10H (antes de la casa familiar)? — `NOT STATED` (vive "en el pueblo"; alojamiento exacto no dicho).
19. ¿Qué fue de la "primera crisis" mencionada del restaurante favorito? — `UNRESOLVED` (mysteries 009).
20. ¿Hubo algún capítulo entre el 8.2 y el 9H.1 que narre la "mudanza" del sistema de rutas individuales en la rama Harem? — El Cap. 8 salta de 8.2 a 8.3H/8.5H/8.6H sin 8.4H; hueco estructural del original (`NOT STATED`).
21. ~~¿Aplica la regla de "mínimo 2 escenas explícitas" al Final Neutro "La Cámara Amiga"?~~ — **OBSOLETA (14/09/2026):** el autor eliminó los finales neutros; solo existe el final feliz. La regla de las 2 escenas explícitas se cumple en toda partida (11M.4, 13M.5, 14M.2).
22. **¿Cuántas casas tiene Sakura-machi y cuántas del valle reparten con la casa?** — `PENDIENTE DE DECISIÓN DE AUTOR` (detectado al escribir el Cap. 14, 17/09/2026). Tres menciones conviven: (a) **cap. 12.6 (Saki):** «En este pueblo hay diecinueve casas»; (b) **cap. 13 (Mika, pizarra y lista):** «las diecinueve casas del valle que reparten con nosotros», y Ren da por buena la cifra «diecinueve casas del valle» como cifra de Mika (13.6); (c) **cap. 14.10 (Ren):** «cuarenta y seis casas del valle han comido pan de este horno desde enero […] más que las diecinueve de **este pueblo**». Opciones de resolución: **(1)** el pueblo tiene 19 casas y el valle 19 clientas fijas del reparto (conviven y hay que decirlo una vez en el cap. 15 para que no parezca error), o **(2)** la cifra 19 es una sola y hay que corregir la mención del valle en el cap. 13. No se ha tocado el texto del cap. 13.

(d) **cap. 16.1 (narración/pizarra, 17/09/2026):** «diecinueve casas en este pueblo y **cuarenta y seis en el valle** desde enero» y «se le apuntan a las otras **cuarenta y seis casas**». Esta mención **coincide con el cap. 14** (46 del valle, 19 del pueblo) y **no con el cap. 13** («diecinueve casas del valle»): el cap. 16 refuerza la opción (2) —el valle reparte con **cuarenta y seis** casas y el 19 de reparto del cap. 13 es el error a corregir— o exige declarar una vez que las «diecinueve» del cap. 13 son las diecinueve del **pueblo**. Sigue `PENDIENTE DE DECISIÓN DE AUTOR`; el texto del cap. 13 no se ha tocado.

# RUTA MIKA — Guion desarrollado (texto de juego)

> Carpeta del guion prosificado de la Ruta Mika. Cada capítulo es un archivo: `capitulo-08M.md` … `capitulo-14M.md`.
> El diseño de producción (estructura, mapa de CGs, reglas) vive en `../ruta-mika.md`. Este guion lo sigue al pie de la letra.
>
> Convenciones: formato invariante del original (`style-guide.md`) · primera persona presente (Hiroshi) · sin puntuación dentro de la ruta · final único feliz · explícito completo desde 11M.4 (regla de autor).
>
> **Estado: RUTA COMPLETA.** Los 7 capítulos (8M–14M) están escritos de principio a fin. 3 escenas explícitas sin elipsis en la trama (11M.4, **13M.5 — la concepción de Hina**, 14M.2) + 2 bonus en el epílogo (E13, E15). **Total: 5 escenas explícitas.**

## Capítulos

| Archivo | Título | Estado | Palabras |
|---|---|---|---|
| `capitulo-08M.md` | El Peso de una Elección | **ESCRITO** (5 escenas + ELECCIÓN 1M, CG 01) | ~3,350 |
| `capitulo-09M.md` | La Chica de la Cámara Rota | **ESCRITO** (5 escenas + ELECCIÓN 2M/3M, CG 03) | ~4,490 |
| `capitulo-10M.md` | Esto No Ha Terminado | **ESCRITO** (CG 04–05) | ~4,820 |
| `capitulo-11M.md` | Sin Máscara | **ESCRITO** — incluye **11M.4 EXPLÍCITA** (CG 08) | ~5,530 |
| `capitulo-12M.md` | El Estreno | **ESCRITO** (CG 09–10) | ~4,740 |
| `capitulo-13M.md` | La Pregunta | **ESCRITO** — incluye **13M.5 EXPLÍCITA: la concepción de Hina** (CG 12/12b) | ~5,900 |
| `capitulo-14M.md` | El Corazón Auténtico | **ESCRITO** — incluye **14M.2 EXPLÍCITA** (CG 14); cierra la ruta (14M.1–14M.5 + post-créditos) | ~6,700 |

**Total de guion desarrollado: ~37,400 palabras** (≈ 260 páginas de guion → 5–6 h de juego con CGs y rejugado).

## Contenido adicional

| Archivo | Contenido | Palabras |
|---|---|---|
| `escenas-opcionales.md` | **12 escenas opcionales de vida cotidiana** (O1–O12) desbloqueables entre capítulos: viñetas de convivencia que amplían el mundo y suman ~1–1.5 h de juego sin tocar la trama | ~3,960 |
| `epilogo-opcional.md` | **Epílogo post-créditos "La vida después del sí"** (E1–E15): 15 viñetas de los años 1–10 de matrimonio, incluida la paternidad (E14, Hina dibuja) + **2 escenas explícitas BONUS (E13 y E15)**, el cuarto y quinto premio explícito de la ruta | ~11,375 |

**Duración total de la Ruta Mika: ~52,700 palabras ≈ 9–10 h de juego** (trama + 5 escenas explícitas [11M.4, 13M.5, 14M.2, E13, E15] + opcionales + epílogo + CGs + rejugado).

## Escenas explícitas (regla de autor: mínimo 2 por final)

| # | Escena | Capítulo | Nota |
|---|---|---|---|
| 1 | 11M.4 — La Primera Noche | 11M | La tesis de la ruta: "sin cámara" |
| 2 | **13M.5 — La Noche del Compromiso (CONCEPCIÓN DE HINA)** | 13M | Penúltima explícita: embarazo consciente, día 12 del ciclo, ventana fértil, eyaculación interna y retención ("quiero tu semilla"). Tema de fertilidad/ovulación (autor, 14/09/2026) |
| 3 | 14M.2 — Noche de Bodas | 14M | Cierre del lema; Mika a ~6 meses de gestación |
| 4 | E13 — El Séptimo Aniversario (BONUS) | Epílogo | Contenido post-créditos, omitible |
| 5 | E15 — "El segundo" (BONUS) | Epílogo | **Concepción del segundo hijo**, mismo tema de fertilidad/ovulación que 13M.5; cuarto premio explícito |

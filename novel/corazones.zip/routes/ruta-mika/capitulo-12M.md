﻿# CORAZONES EN EBULLICIÓN

## CAPÍTULO 12M: EL ESTRENO (RUTA MIKA)

---

## ESCENA 12M.1 - POS-PRODUCCIÓN

NARRACIÓN: *Hay una semana en la que el taller de Sakura-machi deja de ser un taller de cocina y se convierte en una sala de montaje, y nadie lo decidió: simplemente ocurrió.*

*La primera en aparecer fue Yuki, con un ordenador portátil y una cara de concentración que no le había visto ni cuando cocinaba para el festival. La segunda, Ren, con un destornillador y la intención declarada de arreglar el proyector del salón del antiguo restaurante Yamamoto, porque según ella un documental que se estrena con el sonido mal es un documental que se estrena dos veces.*

*Y la tercera, la Señora Tanaka, que llegó con una caja de manzanas y la noticia de que ese salón lleva veinte años cerrado al público.*

SRA. TANAKA: "Si vais a usar el viejo restaurante, al menos que sirva para algo."

MIKA: "¿Nos está dando permiso?"

SRA. TANAKA: "Os estoy diciendo que la cerradura está abierta desde ayer y que la llave está en la caja registradora. Que cada cual lo interprete como quiera."

NARRACIÓN: *Y así, un pueblo que lleva cinco meses saliendo adelante empieza, sin anunciarlo, a producir una película.*

### LA MESA DE MONTAJE

NARRACIÓN: *Mika trabaja de una manera que a mí me resulta imposible de seguir y que a Saki le parece "un crimen contra la organización del tiempo".*

*Tiene el ordenador, dos discos duros, un cuaderno, tres tazas de café y una regla de madera con la que golpea suavemente la mesa cuando quiere que alguien se calle.*

MIKA: "Necesito la toma del mercado a las seis y cuarenta. Y la de las manos de la abuela de las cebollas. Y la del perro del pescadero, que ya sé que no sirve para nada, pero la quiero."

HIROSHI: "¿Por qué la del perro?"

MIKA: "Porque un documental sin perro es un documental sin alma. Es ley."

REN: "Eso no es una ley."

MIKA: "Es una ley de mi estudio. Mi estudio, mis leyes."

NARRACIÓN: *El documental tiene ya un título, escrito con rotulador en la tapa del cuaderno: **"SAKURA-MACHI: LAS MANOS QUE QUEDAN"**.*

*Y tiene una premisa que Mika explicó una sola vez, en voz baja, mirando la pantalla y no a nosotros:*

MIKA: "Cuando llegué aquí me dijeron que el pueblo se estaba muriendo. Y luego vi que no. Que se estaban muriendo las manos. Que había gente que sabe hacer pan, y pescar, y conservar, y nadie lo estaba grabando."

*Pausa.*

MIKA: "Todo el mundo corre a grabar lo que se pierde. Yo quiero grabar lo que se queda."

### YUKI Y LA MÚSICA

NARRACIÓN: *La tarde del tercer día, subo a la sala de arriba y encuentro a Yuki con auriculares puestos, la espalda recta y los ojos húmedos.*

*En la pantalla hay una onda de sonido. En el aire, hay una canción que yo no conozco y que sin embargo reconozco: es una de esas canciones que sólo existen dentro de una casa.*

HIROSHI: "¿Yuki?"

YUKI: "Estoy trabajando."

HIROSHI: "Estás llorando."

YUKI: "También. No son incompatibles."

NARRACIÓN: *Se quita un auricular. Me hace un gesto con la barbilla para que escuche. Pone la canción desde el principio.*

*Es una voz de mujer cantando algo simple, desafinada a propósito en un par de notas, con un ruido de fondo que debe ser una cocina.*

YUKI: "La cantaba mi madre. Mientras cocinaba. Yo la oía desde mi cuarto cuando era pequeña y me parecía horrible porque desafinaba."

*Pausa.*

YUKI: "Es la única grabación que tengo de ella."

NARRACIÓN: *Y ahí me quedo, con una taza de té en la mano y sin saber dónde ponerla.*

HIROSHI: "Yuki, ¿estás segura de que quieres usar esto en la película? Esto es tuyo. Nadie te va a pedir—"

YUKI: "Si no lo uso, se va a quedar en un archivo hasta que se rompa." *Me mira por primera vez en tres días.* "Hiroshi. Aprendí esta semana que las cosas que no se muestran no existen. Y que las cosas que existen merecen que alguien las ponga por escrito."

*Vuelve a ponerse el auricular.*

YUKI: "Va en la escena del pan. A los ocho minutos cuarenta. No discutas."

NARRACIÓN: *No discuto. Bajo las escaleras pensando que la chica que llegó a este pueblo sin poder probar su propia comida acaba de meter la voz de su madre en una banda sonora, y que eso, es un final que nadie le prometió y que se ha ganado sola.*

### REN Y EL SONIDO

NARRACIÓN: *Ren lleva dos días con el proyector del salón del restaurante Yamamoto abierto sobre una manta y las manos llenas de grasa, y en los dos días no ha dicho una sola palabra amable sobre el aparato.*

REN: "Está muerto."

HIROSHI: "¿Muerto muerto?"

REN: "Muerto de abandono, que es peor. La lámpara tiene tres mil horas, el ventilador está tapado con polvo de cinco años, y alguien —no sé quién, pero lo voy a encontrar— guardó aquí dentro una caja de tornillos que no son de este modelo."

MIKA: "¿Se puede arreglar?"

REN: "¿Me estás preguntando si puedo arreglar algo?"

MIKA: "Perdón. ¿Cuánto tiempo te hace falta?"

REN: "Ya está arreglado. Llevo desde ayer esperando a que alguien me preguntara para decirlo."

NARRACIÓN: *Y esa noche, proyectamos en la pared blanca del salón una prueba: quince minutos del documental, sin música, sin títulos, con el proyector que Ren ha resucitado y que suena como un gato ronroneando.*

*Estamos los cinco sentados en las sillas del antiguo restaurante, que Ren ha forrado de nuevo con un rollo de tela que encontró en el almacén. La Señora Tanaka trajo las manzanas. La abuela de las cebollas se trajo su propia silla.*

*Y cuando aparece en pantalla el plano de las manos amasando pan, en el salón del restaurante que llevaba cinco años cerrado, se oye una sola respiración de siete personas al mismo tiempo.*

SRA. TANAKA: "...Mi marido arregló esos techos."

MIKA: "Lo sé. Me lo has contado tres veces."

SRA. TANAKA: "Y lo voy a contar tres más."

NARRACIÓN: *El pueblo se ríe. Y en la risa, hay algo que sólo se oye en las salas pequeñas: el sonido de la gente reconociéndose a sí misma.*

---
## ESCENA 12M.2 - EMI VUELVE (Y SE VA)

NARRACIÓN: *Emi aparece un jueves por la mañana, sin aviso y sin auto rojo. Llega en el autobús de las diez, con una mochila pequeña y esa manera de andar de quien quiere parecer que no busca nada.*

*La veo desde la ventana del taller y lo primero que pienso, es que voy a tener que intervenir. Y lo segundo que pienso es que Ren Takahashi no me ha necesitado para nada en cinco meses y que voy a hacer el ridículo.*

*Así que me quedo en la ventana.*

### PATIO DEL TALLER

NARRACIÓN: *Ren está en el patio, con el mandil de cuero y tres niños del pueblo alrededor. Es la clase de los jueves: filo y afilado, abierta a quien quiera, y hoy hay tres. Uno de ellos tiene siete años y sostiene un cuchillo de cocina con las dos manos, como si fuera una espada.*

*Y Ren, sin levantar la vista del cuchillo que está mostrando, dice:*

REN: "Más despacio. No se corta con la fuerza, se corta con el paso. Si tienes que apretar, el cuchillo está mal y tú estás peor."

*Y entonces levanta la vista y ve a Emi en la verja.*

NARRACIÓN: *Y aquí viene la parte importante de este capítulo, así que voy a contarlo despacio.*

*Ren Takahashi no se pone rígida. No suelta el cuchillo. No se lleva a los niños a otra habitación. Muy al contrario: vuelve a mirar la piedra y sigue explicando, con la misma voz de tres segundos antes.*

REN: "El ángulo. Treinta grados. Ni más ni menos. Ahora tú."

*Y el niño de siete años afila su cuchillo, mal, torcido, con la lengua fuera. Y Ren dice: "mejor". Y el niño sonríe como si le hubieran dado un premio.*

NARRACIÓN: *Emi se queda en la verja. Esperando su turno. Como una clienta.*

### LA CONVERSACIÓN

NARRACIÓN: *La clase termina. Los niños se van. Y Ren limpia la piedra con un trapo, muy despacio, antes de hablar.*

REN: "¿Vienes a gritar?"

EMI: "No."

REN: "¿Vienes a decirme otra vez que yo lo maté?"

EMI: "No."

REN: "Entonces no sé a qué vienes."

NARRACIÓN: *Y Emi da dos pasos dentro del patio, con las manos en los bolsillos, y se queda mirando la piedra de afilar, la mesa de trabajo, la fila de cuchillos colgados en la pared con sus etiquetas puestas a mano.*

EMI: "Vine a ver dónde vives."

*Pausa.*

EMI: "El abuelo habría odiado este silencio. ¿Sabes? Cuatro años sin hablarnos. Él nos habría sentado en una mesa y nos habría obligado a comer hasta que se nos pasara."

REN: "Sí. Lo habría hecho."

EMI: "Nos habría dicho que las familias se rompen por tonterías."

REN: "Y nosotros le habríamos dicho que esto no era una tontería."

EMI: "Y él habría dicho que da igual."

NARRACIÓN: *Silencio. Un pájaro. El ruido de la carretera al fondo.*

REN: "Emi, yo no voy a decirte que no pasó nada. Pasó. Y no voy a decirte que fue culpa tuya, porque no lo fue, y no voy a decirte que fue culpa mía, porque ya no me lo creo."

EMI: "¿Y entonces?"

REN: "Entonces no hay sentencia. Hay un accidente, hay un abuelo que no está, hay dos hermanas que se quedaron sin él y que se echaron la culpa una a la otra porque era más fácil que echársela al aire." *Pausa.* "Y hay un jueves por la mañana con tres niños en un patio."

EMI: "Podía haber venido antes."

REN: "Podías. Pero has venido."

### LA DESPEDIDA

NARRACIÓN: *Emi no se queda a comer. No se abrazan. No lloran. Emi le da un sobre a Ren, cerrado, con una sola cosa escrita encima: "Del cajón del abuelo. Es tuyo."*

*Y Ren no lo abre delante de ella. Lo guarda en el bolsillo del mandil y sigue limpiando la piedra.*

EMI: "El autobús vuelve a las cuatro."

REN: "Lo sé."

EMI: "¿Vas a venir a la estación?"

REN: "No."

NARRACIÓN: *Emi asiente. Y se va andando, sin prisa, por la carretera del pueblo. Y cuando está a veinte metros, Ren dice, en voz alta, sin gritar, hacia la espalda de su hermana:*

REN: "Emi. El cuchillo del abuelo lo tengo yo. Está colgado en la pared, el tercero."

*Pausa.*

REN: "Lo cuido."

NARRACIÓN: *Emi se detiene medio segundo. No se gira. Levanta una mano por encima del hombro y sigue andando.*

*Y ahí se cierra el nudo más viejo de esta ruta. Sin reconciliación completa, sin abrazo, sin perdón dicho en voz alta. Con algo mucho más raro y más real: dos hermanas que se han dejado de acusar.*

### EL SOBRE

NARRACIÓN: *Esa noche, Ren abre el sobre en la cocina, delante de nosotros, porque quiere. Y lo que hay dentro es lo único que podía haber: una fotografía.*

*Una fotografía de un hombre mayor con un mandil y una mujer joven a su lado, con diecisiete años y una cara de no querer estar en la foto, sosteniendo un cuchillo.*

*Ren la mira mucho rato.*

REN: "Tengo esa cara en todas las fotos de mi adolescencia. Es un don."

MIKA: "Ren."

REN: "Estoy bien."

*Pausa. Y luego, muy bajo:*

REN: "Estoy bien. Por primera vez en cuatro años puedo decir esa frase y no estar mintiendo."

NARRACIÓN: *Cuelga la foto en la pared del patio, entre la piedra de afilar y la fila de cuchillos. En el tercer sitio, junto al del abuelo.*

*Los hechos de aquel accidente, no los sabremos nunca. No están en esta historia. Lo que estaba en esta historia era el silencio, y el silencio se ha roto.*

---

## ESCENA 12M.3 - LAS CAMPANAS ERAN SUYAS

NARRACIÓN: *La escena empieza, con Saki de pie en el salón del antiguo restaurante Yamamoto, con las manos en la cintura y esa cara que pone cuando va a decir una cifra que nadie va a discutir.*

SAKI: "He hablado con la Señora Tanaka. Voy a arrendar el local."

MIKA: "¿El... el salón?"

SAKI: "El restaurante entero, querida. Sabes perfectamente de qué estoy hablando."

HIROSHI: "¿Y qué vas a hacer con él?"

SAKI: "Reabrirlo."

NARRACIÓN: *Y ahí, nadie dice nada durante cinco segundos, porque todo el mundo está calculando lo mismo a la vez.*

*El restaurante Yamamoto, cerrado cinco años. El sitio donde la familia Yamamoto servía comida durante generaciones. El local que la Señora Tanaka y su difunto marido compraron "por si algún día alguien lo quería".*

MIKA: "¿Con qué nombre?"

*Pausa larga.*

SAKI: "Restaurante Yamamoto."

REN: "Eso es el nombre del local, no el tuyo."

SAKI: "Es el mismo nombre."

NARRACIÓN: *Y es aquí donde Saki hace lo que llevaba preparando desde el Capítulo 6 y que ninguna de nosotras había visto.*

*Saca de la bolsa un paño de tela gruesa, lo pone sobre la mesa de montaje y lo abre. Dentro hay cuatro campanas de plata pequeñas: las del ritual de apertura del festival, esas que suenan cuando el primer cliente cruza la puerta.*

*Las mismas que le entregó la Señora Tanaka en la madrugada del festival y con las que Saki lagrimeó sin explicar por qué.*

SAKI: "Estas campanas son de mi familia."

MIKA: "Saki, la Señora Tanaka dijo que eran de—"

SAKI: "De la familia Yamamoto. Sí." *Respira.* "Lo dijo porque es lo que son. Yo no te mentí, querida. Sólo no conté todo lo demás."

NARRACIÓN: *Y ahora, la historia completa, dicha sin adornos, con las campanas delante.*

SAKI: "Los Yamamoto de este pueblo tenían dos ramas. La de aquí, la que montó el restaurante. Y la de la ciudad, mi abuela. Se separaron por una herencia hace sesenta años y no se volvieron a hablar, porque en este país las familias se rompen por cosas más pequeñas que esa."

*Pausa.*

SAKI: "Yo crecí con el apellido y con la historia, pero sin el pueblo. Cuando decidí dejar la capital y buscar un sitio donde volver a poner la mesa, busqué el apellido en los registros. Y apareció Sakura-machi."

MIKA: "¿Viniste aquí por eso? ¿Por tu apellido?"

SAKI: "Vine aquí porque era el único sitio del mapa donde mi apellido significaba algo." *Pausa.* "Y me quedé porque resultó que significaba vosotras."

NARRACIÓN: *Silencio. Saki mira las campanas.*

SAKI: "Cuando la Señora Tanaka me las puso en las manos, supe dos cosas. La primera: que ella sabía. Lleva setenta años viviendo aquí, sabe de quién es cada cuchara del mercado. La segunda: que yo llevaba dos meses comiendo en la mesa de un pueblo que era mío por sangre y en el que no me había atrevido a decir mi nombre completo."

REN: "¿Y por qué ahora?"

SAKI: "Porque el proyector funciona y el salón está abierto y hay una niña que va a estrenar una película sobre este pueblo." *Se gira hacia Mika.* "Y porque si voy a poner mi nombre en ese cartel, quiero que esté bien escrito."

---

### LA SEÑORA TANAKA LO SABÍA

NARRACIÓN: *La vamos a ver esa misma tarde. Las tres en el mercado, con Saki delante del mostrador y la Señora Tanaka pesando manzanas como si la conversación no fuera con ella.*

SAKI: "Señora Tanaka."

SRA. TANAKA: "Saki Yamamoto. Qué raro suena, ¿verdad? Con todas las veces que te he puesto el apellido delante y tú has hecho como que no lo oías."

SAKI: "Lo sabía."

SRA. TANAKA: "Lo supe el primer día, cuando te presentaste. Lo supe porque tienes la nariz de la abuela de los Yamamoto, la que vivía en la casa de la esquina y bajaba a comprar el pescado los viernes."

*Pausa.*

SRA. TANAKA: "Y no dije nada porque no me pareció asunto mío. Cada cual cuenta su historia cuando puede, no cuando le preguntan."

SAKI: "El local—"

SRA. TANAKA: "El local lleva cinco años vacío y mi marido llevaba cinco años esperando que alguien de verdad lo quisiera. No te voy a cobrar lo que vale. Te voy a cobrar lo que tú puedas pagar y lo que él habría querido."

*Mira a Saki con una sonrisa pequeña.*

SRA. TANAKA: "Y en la puerta vas a poner su nombre. Porque era su casa antes de ser tu herencia. Y porque a mí me hace ilusión."

### EL RITUAL DE LAS CAMPANAS

NARRACIÓN: *El sábado por la mañana hay una docena de personas en la puerta del restaurante: la Señora Tanaka, Jiro, la abuela de las cebollas, el pescadero, los tres niños de la clase de los jueves, el panadero, y los cinco.*

*Saki llega con la llave en la mano. Se queda un momento delante de la puerta cerrada. Y luego se vuelve hacia nosotros y dice, con una voz distinta a todas las que le hemos oído:*

SAKI: "Este es el mismo orden que hacía mi tía. Se abre con la campana, no con la llave."

*Y hace sonar las cuatro campanas de plata, una detrás de otra, marcando el ritmo que la Señora Tanaka le enseñó en la madrugada del festival.*

NARRACIÓN: *Y abre la puerta.*

REN: "Nadie va a aplaudir, ¿verdad? Porque hay doce personas y ninguna tiene esa costumbre."

PESCADERO: "¡Ole!"

REN: "Ha aplaudido el pescadero. Muy bien. Así está la hostelería en este país."

NARRACIÓN: *Y entramos todos. La Señora Tanaka llora. La abuela de las cebollas, que no llora nunca, se limpia la nariz con el dorso de la mano y dice que es por el polvo. Saki no llora: Saki mira el local de arriba abajo con ojo de compradora, calculando mesas, mermas y metros de barra.*

SAKI: "Aquí caben treinta comensales. Cuarenta si quitamos el aparador."

SRA. TANAKA: "Cuarenta y dos. Mi marido lo midió tres veces."

SAKI: "Cuarenta y dos, entonces."

NARRACIÓN: *Y ahí concluye el hilo que empezó en la primera semana con una mujer bajando de un autobús con dos campanas y un apellido. Ese restaurante va a reabrir en primavera, con el nombre que llevaba en el letrero desde antes de que yo naciera, y detrás de la barra va a estar la única persona del pueblo que corta las cebollas más rápido que yo.*

*El pueblo que se estaba muriendo acaba de contar un local más.*

---

## ESCENA 12M.4 - ELECCIÓN 6M: EL PLANO FINAL

NARRACIÓN: *La noche antes del estreno, Mika me despierta a las dos de la mañana con el ordenador abierto y una cara de pánico que hasta ahora sólo le había visto el día del festival.*

MIKA: "Falta el plano final."

HIROSHI: "¿Cómo que falta?"

MIKA: "Tengo todo. Tengo las manos, tengo el pan, tengo el pescado, tengo la voz de tu madre—" *se corrige* "—la voz de la madre de Yuki. Tengo el perro. Tengo todo y no tengo el final. Y se estrena en catorce horas."

HIROSHI: "¿Qué es lo que quieres contar?"

MIKA: "Eso es lo que no sé."

NARRACIÓN: *Y entonces me enseña tres finales posibles, los tres montados, los tres con música puesta, los tres de dos minutos. Y me pide que elija yo.*

*Y aquí llega mi turno. Mika Nakamura lleva cinco meses decidiendo sola todo lo que graba. Y esta noche ha venido a buscarme a mí.*

### ELECCIÓN 6M:

**OPCIÓN A: "Las manos, abuela por abuela."**
*Primer plano de las manos de las abuelas del pueblo: la de las cebollas, la del pescado, la del miso. Sin caras. Sin nombres. Sólo manos que trabajan.*
`[Cierre sereno. Mika me agradece la idea y la usa.]`

**OPCIÓN B: "El pueblo que ella dibujó."**
*Los dibujos de Akari —los de la caja de madera— animados sobre las imágenes reales del pueblo, hasta que en el último plano el dibujo y la realidad coinciden exactamente y no se sabe cuál es cuál.*
`[El final verdadero de la ruta. Sólo está disponible si elegiste la Opción C en 11M.2 (pedirle salir frente al rincón de su hermana).]`

**OPCIÓN C: "El pueblo entero, sin narración."**
*Tres minutos de sonido ambiente y vecinos en su vida: nadie habla, nadie explica. Cierre de autor, frío y enorme.*

---

NARRACIÓN: *Y esta es la parte que importa: elija lo que yo elija, la película se termina y el pueblo se llena. No hay final malo aquí.*

*Pero si elijo lo de los dibujos, Mika se queda mirándome un segundo largo, y luego hace algo que no le había visto nunca: apaga la pantalla del ordenador y se queda a oscuras, con la cara iluminada sólo por la luz de la calle.*

MIKA: "¿Cómo sabías que tengo los dibujos?"

HIROSHI: "Me lo contaste la primera semana. En el parque. Dijiste que tu hermana dibujaba pueblos."

MIKA: "Hace cinco meses de eso."

HIROSHI: "Sí."

MIKA: "Y tú te acuerdas."

NARRACIÓN: *Y ahí, con la ciudad a oscuras y una película a catorce horas de existir, Mika Nakamura me mira como se mira a alguien que lleva tiempo escuchando de verdad.*

MIKA: "Anímame a hacerlo."

HIROSHI: "¿Lo necesitas?"

MIKA: "Lo necesito porque va a llorar todo el pueblo, y yo voy a estar al lado del proyector, y no quiero estar sola cuando eso pase."

HIROSHI: "Entonces yo estaré al lado del proyector."

MIKA: "Vale." *Pausa.* "Vale."

NARRACIÓN: *Y se pasa la noche trabajando, y yo me quedo dormido en la silla, y a las siete de la mañana me despierta con un vaso de agua en la mano y una sonrisa del tamaño del mercado entero.*

MIKA: "Ya está. Es perfecto. Odio y amo a partes iguales. Eso significa que funciona."

---

## ESCENA 12M.5 - EL ESTRENO

NARRACIÓN: *El estreno se hace en la plaza, porque en el salón del restaurante caben cuarenta y dos y en la plaza caben todos.*

*Ren instala el proyector sobre dos cajas de madera y una sábana blanca clavada entre dos postes del alumbrado. La abuela de las cebollas trae su propia silla desde las siete de la tarde. El pescadero cierra el puesto dos horas antes por primera vez en treinta años. El panadero hace pan para el final, porque según él "esto se va a celebrar de alguna manera".*

*Y a las nueve, cuando ya hay más de doscientas personas en la plaza, y la Señora Tanaka ha puesto las cuatro campanas de plata sobre la mesa de proyección como quien pone un centro de flores, Mika Nakamura sube a la silla que usamos de trípode, mira a doscientas personas y se queda sin voz.*

*Cinco segundos.*

*Y entonces dice:*

MIKA: "Buenas noches. Soy Mika. Soy la que ha hecho esto. Y no voy a dar un discurso porque no sé hacerlo sin cámara."

*Risas.*

MIKA: "Solo quiero decir una cosa antes. Cuando llegué a este pueblo hace casi un año, me dijeron que aquí ya no había nada. Y luego me senté en esa mesa de ahí—" *señala el taller* "—y comí la mejor comida de mi vida con cuatro personas que no conocía de nada."

*Pausa.*

MIKA: "Esta película es sobre este pueblo. Pero también es para mi hermana. Mi hermana Akari dibujó este pueblo antes de que yo lo encontrara."

NARRACIÓN: *Y ahí se hace un silencio tan grande en la plaza de Sakura-machi que se oye el proyector arrancar.*

### LA PELÍCULA

NARRACIÓN: *Y empieza.*

*Y voy a contarte lo que pasa en los ochenta minutos siguientes, porque hay cosas que no se pueden dejar fuera de esta crónica.*

*Pasa que en el minuto tres se ve el mercado de la Señora Tanaka por dentro, con la luz de las siete de la mañana, y el sonido de las latas de conserva y una voz que dice "buenos días" y que resulta ser la del difunto marido de la Señora Tanaka, grabada de un casete que Mika encontró en un cajón sin pedir permiso, y que la Señora Tanaka le dio al día siguiente sin decir nada — sólo se lo puso en la mano y le dio la espalda.*

*Pasa que en el minuto doce se ve la cocina del taller con los cinco trabajando y sin música, y se oye a Ren decirle a Mika "no me grabes mientras afilo, mujer, que se me va el pulso", y Mika contestar "si no te grabo, no existe", y Ren contestar "pues que no exista".*

*Pasa que en el minuto veintitrés aparece la abuela de las cebollas empujando su carrito, y la abuela de las cebollas, en la plaza, se tapa la cara con las dos manos y todo el mundo se ríe y ella amenaza con irse y no se va.*

*Y pasa que en el minuto cuarenta, con la escena del pan, entra la voz de la madre de Yuki, desafinando exactamente en la misma nota de siempre, y Yuki Hayashi, sentada en la primera fila con la espalda rectísima, se lleva la mano a la boca y no aparta los ojos de la pantalla.*

*Nadie del pueblo sabe de quién es esa voz. Sólo nosotros cuatro. Y en la plaza, en la primera fila, una chica de dieciocho años está escuchando a su madre cantar delante de doscientas personas y no está llorando de pena.*

### EL FINAL

NARRACIÓN: *Y llega el final. El final que montamos a las siete de la mañana.*

*La imagen del pueblo real — el mercado, la plaza, la parada del autobús, la carretera de la montaña. Sin música. Sin narración. Sólo el viento y un perro.*

*Y encima de esa imagen, despacio, empieza a hacerse transparente un dibujo.*

*Primero una línea. Luego una ventana. Luego un tejado. Luego el cartel del mercado, dibujado con una letra torcida de niña, con la misma forma exacta que tiene el cartel real. Y luego la parada del autobús. Y luego la banca del parque. Y luego, en un trazo tembloroso, un cerezo que no da cerezas.*

*Y cuando el dibujo queda completo encima de la imagen real, se superponen tan exactamente que no se sabe cuál es cuál.*

*Y en la plaza de Sakura-machi, doscientas personas de las que la mitad no conocía a Akari Nakamura entienden al mismo tiempo que alguien dibujó este pueblo antes de haberlo visto.*

NARRACIÓN: *Silencio de tres segundos.*

*Y luego, en la primera fila, alguien ríe. Es el pescadero. Y su risa es tan absurda, tan inoportuna y tan verdadera que se contagia: primero a los tres niños de la clase de los jueves, luego a la abuela de las cebollas, luego a Jiro, luego a la Señora Tanaka, luego a doscientas personas.*

*Y lloran y ríen a la vez, como se llora y se ríe en los velorios de los que fueron felices.*

### DESPUÉS

NARRACIÓN: *Los créditos llevan dos minutos y van con los nombres de todo el pueblo, incluidos los que sólo trajeron una silla.*

*En la última línea, en letra pequeña, dice:*

*"PARA AKARI NAKAMURA. QUE DIBUJÓ ESTE PUEBLO ANTES DE QUE YO LO ENCONTRARA."*

NARRACIÓN: *Y Mika, que ha pasado los ochenta minutos de pie junto al proyector, con la mano de Yuki en una mano y la mía en la otra, se gira hacia mí cuando se encienden las luces y me dice, con los ojos rojos y la voz destrozada:*

MIKA: "No he grabado nada de esto."

HIROSHI: "Lo sé."

MIKA: "Lo he vivido entero."

HIROSHI: "Lo sé."

NARRACIÓN: *Y ahí acaba el capítulo, con la plaza llena, con el pan del panadero repartiéndose entre doscientas personas, con las cuatro campanas de plata sonando encima de la mesa de proyección porque el pescadero ha decidido que eso hay que celebrarlo, y con una mujer que acaba de contar la cosa más importante de su vida sin grabar ni un segundo.*

*Kenji no ha aparecido. Kenji no ha llamado. Kenji, según supimos después, ni siquiera contestó al correo que Mika le mandó para invitarlo.*

*El tipo que hace un año tenía tres contratos sobre ella no tiene ya absolutamente nada que vender, porque nadie va a comprar la historia de un pueblo que la cuenta mejor que él.*

PRÓXIMO: Capítulo 13M - "La Pregunta"

---

﻿## CAPÍTULO 11M: SIN MÁSCARA

*(Dos semanas después del puente. Escrito como espejo estructural del Capítulo 11H del original: sube la escalera de intimidad al nivel explícito, y el corazón de la ruta se dice en voz baja.)*

---

## ESCENA 11M.1 - MAÑANA SIN PERSONAJE

NARRACIÓN: *Hay una mañana, dos semanas después del puente, en la que Mika Nakamura baja a la cocina sin la sudadera amarilla del gato.*

*Lo digo así porque así hay que decirlo: llevaba la sudadera amarilla desde el primer día. Era su uniforme de trabajo y de armadura — cuando la llevaba puesta, cada frase salía con dos intentos de anticipación, cada gesto venía con un cálculo de encuadre. Esa mañana baja con una camiseta gris y el pelo recogido mal, torcido a un lado, y se queda parada en el marco de la puerta de la cocina mirándonos cocinar como quien entra a un sitio por primera vez.*

REN: "¿Y eso?"

MIKA: "¿Qué es 'eso'?"

REN: "No llevas la capa de superheroína."

MIKA: "Es que ya no hace falta. Un día más con eso puesto y la lavadora se declara en huelga." *Se estira, con las manos en los riñones y un crujido de columna de veintitrés años mal vividos.* "¿Saben qué?"

NARRACIÓN: *Y aquí, el grupo entero se detiene. Porque en cinco meses hemos aprendido que "¿Saben qué?" es la fórmula de entrada de un chiste preparado — la marca de fábrica, el tintineo de campanilla antes del número.*

*Saki levanta la vista de su libreta. Ren deja de picar. Yuki, que estaba catando la sopa, se queda con la cuchara en alto.*

MIKA: "No se me ocurre nada. No tengo chiste. Estoy... bien. Solo eso. Estoy bien y quería decirlo en voz alta sin que fuera una noticia."

NARRACIÓN: *Silencio de tres segundos.*

YUKI: "Entonces la sopa está lista."

REN: "Pues vale."

SAKI: "Anotado."

MIKA: "¡'Anotado', dice! ¡Mi madre, qué familia más expresiva!"

*Y se ríen, y el desayuno sigue, y nadie capitaliza el momento. Eso es una familia: el día que uno deja de actuar, alguien le pasa el té.*

---

## ESCENA 11M.2 - ELECCIÓN 4M: PEDIRLE SALIR (OFICIALMENTE)

NARRACIÓN: *Y ahora, el capítulo de romance empieza de verdad, y empieza como empiezan estas cosas: buscando el momento. El momento que no existe.*

*Durante tres días intento encontrar la oportunidad. La cocina está llena a todas horas. El taller está lleno. El pueblo entero está lleno, porque desde el puente Sakura-machi nos trata con una familiaridad nueva — nos traen mandarinas, nos preguntan por el "chico de la sopa", nos piden recetas. Mika está radiante en público y no dice nada en privado, y yo llevo dos semanas con una frase en el bolsillo que no encuentro dónde decir.*

*Hasta que entiendo que la frase no necesita un sitio. Necesita una decisión. Y esa decisión es mía:*

### ELECCIÓN 4M:

**OPCIÓN A: A solas, en la cocina, después del cierre — cuando todo el mundo se ha ido.** `[íntima, sin testigos — vía silenciosa]`

**OPCIÓN B: Durante la filmación de la nota del día, dejando que la cámara la pille desprevenida.** `[desbloquea CG 06: "El plano que no se cortó" — el público como testigo elegido]`

**OPCIÓN C: En el parque, frente al rincón de su hermana. Pidiéndole permiso a ella primero.** `[EL CAMINO VERDADERO — pico emocional de la ruta]`

> **Nota de producción:** las tres opciones terminan en el mismo lugar del corazón. Solo la C convierte la petición en un acto familiar: porque quien pide permiso no pide permiso para sí mismo, pide permiso para que alguien cuide lo que él cuidaba.

---

### 11M.2-A — LA COCINA VACÍA

NARRACIÓN: *Espero a que Ren se lleve los últimos cuchillos al estante y a que Saki apague la lámpara del escritorio. La cocina se queda con una sola luz, la de la campana, que es la luz más honesta que hay: no embellece nada.*

MIKA: "Estás raro."

HIROSHI: "Estoy pensando."

MIKA: "Peligroso."

HIROSHI: "Mika. Quiero pedirte algo, y quiero pedírtelo sin que suene a transacción. Ni contrato, ni condición, ni cláusula. Solo una pregunta."

MIKA: "..." *Se sienta en el taburete, despacio, como quien se prepara para una cata.*

HIROSHI: "¿Quieres salir conmigo? Cita. Con nombre y fecha. De las que se apuntan en un calendario de verdad, de cartón, aunque se nos olvide el bolígrafo."

MIKA: "¿Y si digo que sí, esto se vuelve contenido?"

HIROSHI: "Se vuelve lo que tú decidas que sea. Y mañana, y en el piso de arriba, también."

NARRACIÓN: *Y ella hace una cosa que no le he visto hacer nunca: se lleva las dos manos a la cara, como una quinceañera de comedia, y se ríe con un alivio tan grande que casi es llanto.*

MIKA: "Sí. Sí, quiero. Y quiero que la primera cita sea... sea lo que tú elijas, porque no me acuerdo de cómo se elige algo que no sea una portada."

---

### 11M.2-B — LA CÁMARA QUE NO SE CORTA

NARRACIÓN: *Ella está grabando la nota del día. Yo estoy detrás del encuadre, en el lugar del ayudante, y el foco rojo está encendido.*

*Y decido que ya está bien de esconderse.*

HIROSHI: "Mika. No cortes."

MIKA: "¿Qué? ¿Se ve algo raro? ¿Tengo—?"

HIROSHI: "No cortes. Quiero que quede grabado. Quiero preguntarte algo delante de la única testigo que siempre has respetado."

MIKA: "..." *Los dedos en el borde del trípode, quietos.*

HIROSHI: "¿Quieres salir conmigo? Cita. Con nombre y fecha. Una cita de las que se pueden contar, porque no me da miedo que se cuente."

NARRACIÓN: *Y Mika mira el foco rojo. Y por primera vez en cinco meses el foco rojo no es una amenaza: es una promesa con testigo. Sonríe a la lente como se sonríe a un amigo de la familia.*

MIKA: "Sí. Y deja de reírte, que se te oye."

*(CG 06: "El plano que no se cortó" — Mika sonriéndole a la cámara, la mano de Hiroshi entrando al cuadro desde el borde.)*

---

### 11M.2-C — EL PARQUE (CAMINO VERDADERO)

NARRACIÓN: *El rincón del parque lleva desde el primer día con la banca torcida y el cerezo que no da cerezas. En la banca, Mika puso hace cinco meses una placa de madera que hizo ella misma a mano, torcida, con las letras quemadas con un soldador: "AKARI NAKAMURA — LA PERSONA MÁS SABIA QUE CONOCÍ".*

*Me siento a su lado. El sol de la tarde entra por el lado del mercado, y hay una abuela con un carrito lleno de cebollas que nos mira dos segundos y sigue.*

HIROSHI: "Vine a pedirte permiso."

MIKA: "¿Permiso? ¿Para qué?"

HIROSHI: "Para esta pregunta." *Respiro. Mejor deprisa, antes de que la voz se me temple y suene a discurso.* "Mika. Quiero salir contigo. Cita con nombre y fecha, la primera de muchas si me dejas. Pero no vengo a pedirte permiso solo a ti. Vengo a pedírselo a ella también. No para mí. Para que él sepa quién cuidará a su hermana."

NARRACIÓN: *Y el parque se queda en silencio largo, largo. La abuela de las cebollas ha dejado de empujar el carrito. El perro del pescadero ladra una vez y se calla, y juro que el perro entiende más que yo.*

*Mika no llora. Mira la placa, mira la madera torcida, mira la N de NAKAMURA, que le quedó más grande y medio derretida.*

MIKA: "Hiroshi."

HIROSHI: "Dime."

MIKA: "Ella habría dicho que sí en la primera frase. Era de las que decían sí a todo lo que tuviera buena intención y mal cálculo." *Se le rompe la risa en la mitad y sale un sonido pequeñito.* "Pero yo soy la que tiene que decir sí. Y digo sí. Sí, quiero. Sí, cuida de mí. Y sí, ella lo sabe."

*Pone la mano encima de la placa.*

MIKA: "¿Sabes qué me dio más miedo de ti? Que cocinas como si la comida fuera de alguien. Los demás cocinan como si la comida fuera de nadie. Tú cocinas como si cada plato tuviera dueño. Eso es lo único que le habría importado."

NARRACIÓN: *Y ahí, con la abuela de las cebollas y el perro del pescadero como únicos testigos — un reparto que cualquier guionista pagaría por tener —, se cierra el pacto más importante de esta ruta.*

*Porque no es una declaración. Es una adopción: la de dos, y también la de ella.*

---

## ESCENA 11M.3 - LA CITA

NARRACIÓN: *La primera cita oficial de Mika Nakamura y Hiroshi Matsuda se llama, en el calendario de cartón que Saki nos regaló, "FESTIVAL DE VERANO — PRIMERA CITA (NO LLEVAR TRABAJO)".*

*Lo escribió Saki. Con rotulador rojo. Lo subrayó dos veces.*

*El festival de verano de Sakura-machi no es un festival de ciudad: es un tramo de calle, treinta puestos, un escenario con un altavoz de los años ochenta, y todo el pueblo con ropa de verano que solo se pone una vez al año. Huele a yakisoba, a caramelo de manzana y a cera de farol.*

*Y Mika Nakamura aparece con un yukata azul.*

NARRACIÓN: *Se lo digo directamente, porque merece su propia línea: llevaba cinco meses viéndola con amarillo de gato, con gris de jornada larga, con colores de escenario y colores de descanso. Nunca la había visto elegir un color para sí misma.*

*El azul es profundo, con un patrón de olas pequeñas en la tela. El pelo recogido, un par de horquillas. Un abanico. Nada de cámara, nada de móvil, nada de trípode.*

MIKA: "No digas nada."

HIROSHI: "No digo nada."

MIKA: "Estás diciendo todo."

HIROSHI: "Estoy callado como un profesional."

MIKA: "Mentiroso. Se te nota el ruido."

*(CG 07: "Yukata azul" — Mika bajo los faroles, el abanico medio abierto, la tela azul con olas.)*

NARRACIÓN: *Caminamos. Ganamos un peluche en el puesto de las ranas — lo gano yo, en el tercer intento, y ella lo pierde un puesto después porque le da ternura el rana fea que nadie quiere. Comemos yakisoba de un mismo plato con dos palillos. Nos encontramos a la Señora Tanaka, que finge no ver nuestra mano en la mano con una habilidad de diplomática.*

SRA. TANAKA: "Ah, jovencitos. ¿Han probado el puesto de tamagoyaki? El dueño es un desastre con el fuego, pero la intención vale el precio."

MIKA: "Señora Tanaka, ¿nos está dejando solos a propósito o es un cumplido?"

SRA. TANAKA: "Las dos cosas, querida. Las dos cosas se pueden hacer a la vez. Es lo que me enseñó mi difunto marido." *Y se va, dejándonos con la boca abierta y un tamagoyaki gratis.*

NARRACIÓN: *Y más tarde, en el puesto de las máscaras de papel, Mika compra una máscara de zorro.*

*Roja y blanca, con las orejas puntiagudas. Se la pone y me mira por los agujeros de los ojos con esa sonrisa que siempre lleva dos segundos de ventaja.*

MIKA: "Prueba social, Hiroshi. Un objeto de prueba sin consecuencias. Ahora nadie sabe quién es la que habla."

HIROSHI: "¿Y qué va a decir la del zorro?"

MIKA: "Cosas que la Mika normal no diría a la vista." *Avanza un paso, con la máscara puesta, muy cerca.* "Por ejemplo: que llevo desde el primer día queriendo saber si tu serenidad es carácter o es una costumbre de la ciudad."

HIROSHI: "¿Y bien?"

MIKA: "Que es carácter. Y eso sí que da miedo, porque entonces no es que te aguantes. Es que no tienes miedo."

HIROSHI: "Tengo miedo. Tengo miedo de que un día el zorro se vaya y no vuelva el resto."

NARRACIÓN: *Se baja la máscara. Un grado, solo un grado, la inclina hacia arriba, dejando ver la barbilla y los ojos.*

MIKA: "El zorro era lo que me daba miedo. Lo otro era la cárcel. Ya no."

*Se sube otra vez la máscara, y añade, en el tono de quien ya no puede parar:*

MIKA: "Y por cierto — esto no lo diría Mika Nakamura en un directo: si quieres subir arriba cuando volvamos, yo también quiero. Digo. Por información. Para que la logística no te pille desprevenido."

NARRACIÓN: *Los faroles. El altavoz viejo con una canción de verano. La máscara de zorro inclinada. El perro del pescadero pasando por delante y ladrando, otra vez, exactamente en el momento equivocado.*

*Y entonces la escena me pide algo. Porque ella ha dejado la puerta abierta sin empujar a nadie dentro, y lo que decida ahora no cambia el destino de la noche — cambia el sabor con que se llega.*

### ELECCIÓN 5M:

**OPCIÓN A: "Subimos. Sin discurso, sin preguntas. La honestidad también se dice con los pies."** `[vía directa]`

**OPCIÓN B: "Llegamos arriba y te lo digo todo primero. Entero. Antes de cruzar esa puerta."** `[CAMINO VERDADERO — desbloquea la secuencia extendida de 11M.4]`

**OPCIÓN C: "Te pregunto si estás segura. Quiero oírlo con el zorro puesto."** `[variante tierna — más lenta]`

> **Nota de producción:** las tres convergen en la misma noche. La B añade la confesión completa; la C, la confirmación del zorro; la A, la velocidad. Ninguna evita lo que sigue, porque desde el momento en que ella dijo "yo también quiero" no hay nada que evitar.

---

## ESCENA 11M.4 - LA PRIMERA NOCHE (EXPLÍCITA)

NARRACIÓN: *El piso de arriba del mercado tiene una escalera de madera que cruje en el tercer escalón y una habitación con una cama individual que es demasiado estrecha para dos, y que ninguno de los dos va a mencionar.*

*Subimos sin luz. Mika va delante y yo detrás, y el azul del yukata se mueve en la oscuridad como agua. En el rellano se para, se quita las horquillas una a una y las deja en el alféizar, como quien deja las armas en la puerta.*

*Luego se gira. Y en la penumbra, con los faroles del festival colándose por la ventana en franjas naranjas, me mira.*

MIKA: "Antes de nada. Una cosa, y es importante."

HIROSHI: "Dime."

MIKA: "No voy a grabar nada. Ni audio, ni vídeo, ni nota de voz, ni 'lo cuento mañana en el canal'. Esta noche no se publica. Esta noche no se edita. Esta noche no existe para nadie que no seamos tú y yo. ¿Entendido?"

HIROSHI: "Entendido."

MIKA: "Dilo entero. Quiero oírlo entero, porque llevo tres años oyendo promesas a medias."

HIROSHI: "Esta noche es tuya. Sin cámara, sin testigos, sin mañana. Y si en algún momento quieres parar, dices mi nombre y paramos. Y si quieres que siga, también lo dices."

NARRACIÓN: *Y ahí suelta el aire que llevaba aguantando desde el festival. Sonríe, y la sonrisa le tiembla en la boca de una manera que no le había visto nunca: no es la de la marca, ni la de la cámara, ni la que se practica dos veces frente al espejo. Es la de la mitad que no se vende.*

MIKA: "Vale. Entonces ven aquí."

NARRACIÓN: *Y el primer beso de esa noche no es como el del río. El del río era una llegada. Este es una decisión: lo siento en la manera en que me toma de la nuca, sin prisa, con las dos manos, como si estuviera comprobando que estoy entero y entero ahí.*

*Le desato el obi con cuidado y la tela azul se afloja entre mis dedos como si hubiera estado esperando. El yukata se abre solo. Debajo no hay nada: nada de ropa pensada para un plano, nada de armadura, solo ella, la piel tibia de la tarde de verano y el olor a jabón y a caramelo de manzana del festival.*

MIKA: "Uy. Rápido."

HIROSHI: "¿Paro?"

MIKA: "Ni se te ocurra. Solo digo que—" *se ríe, con la frente apoyada en mi hombro, y la risa le vibra en todo el cuerpo* "—solo digo que me lo imaginé tantas veces que ahora me da pudor no tener guion."

MIKA: "Dime tú algo. Que no sea bonito. Bonito ya lo tengo en la cabeza. Dime algo verdadero."

HIROSHI: "Te deseo. Desde antes de saber qué eras. Y no sé hacerlo con palabras finas."

MIKA: "..." *Y ahí el temblor se le va y le queda sitio para otra cosa.* "Menos mal. Las palabras finas son de gente que no ha soportado un invierno."

NARRACIÓN: *El yukata cae al suelo en un charco azul. Ella me desabrocha la camisa con dedos expertos de quien ha desmontado trípodes a oscuras, botón a botón, sin mirar. Cuando llega al último se detiene y me pone la mano abierta en el pecho, sobre el esternón, donde está el latido que llevo desde el primer día del pueblo.*

MIKA: "Ahí está."

HIROSHI: "¿El qué?"

MIKA: "El ruido. Llevo meses queriendo oírte el ruido."

NARRACIÓN: *Nos movemos hacia la cama y la cama cruje, y los dos nos reímos de la cama, y ese es el sonido con el que empieza todo lo bueno: una risa doméstica, sin público.*

*La desnudo del todo a la luz de los faroles. La miro despacio, entera, sin prisa, porque llevo cinco meses aprendiéndome su cara y todavía no me sé el resto. Las marcas de la vida en ella — la cicatriz diminuta del codo, la línea del hombro, el nacimiento de la cadera — no son un cuerpo de portada. Son un cuerpo de persona. Y a mí me parece el hallazgo del año.*

MIKA: "No me mires así."

HIROSHI: "¿Cómo?"

MIKA: "Como si estuvieras guardando la foto. Se supone que esta noche no se guarda nada."

HIROSHI: "No estoy guardando la foto. Estoy aprendiendo. Es distinto."

NARRACIÓN: *Y se calla, porque sabe que es distinto. Me pone una mano en el pecho y empuja un poco, hasta que la espalda me toca el colchón y queda ella encima, sentada sobre mí, con la melena cayendo a un lado y la luz naranja cruzándole la clavícula.*

MIKA: "Yo mando esta noche. Es la regla de la casa."

HIROSHI: "¿Y cuántas reglas tiene esta casa?"

MIKA: "Cuatro. Regla uno: yo mando. Regla dos: si te ríes, sigo. Regla tres—" *se inclina, la boca a un centímetro de la mía* "—no hay regla tres. La tres era para asustar."

NARRACIÓN: *Y la beso hasta que se le olvida la regla uno, y ella me la recuerda mordiéndome el labio. Mis manos le bajan por la espalda, vértebra a vértebra, y se quedan en la curva de la cadera; sus caderas responden antes que su voz, un movimiento lento que me deja sin aire y que ella registra con una risa pequeña, satisfecha, directamente contra mi cuello.*

*Entonces me quita la camisa del todo y se incorpora para mirarme, y hay un segundo en que ninguno de los dos se mueve y en el que se decide toda la noche: porque no se está midiendo nada, solo comprobando, con los ojos, que los dos estamos aquí.*

MIKA: "Dime mi nombre."

HIROSHI: "Mika."

MIKA: "Otra vez. Suena distinto cuando lo dices tú."

HIROSHI: "Mika."

NARRACIÓN: *Y se inclina y me besa como si me lo estuviera cobrando.*

*Después las cosas se vuelven lentas y exactas. La recorro con la boca: la curva del hombro, el hueco entre las clavículas, la parte baja del esternón donde el pulso golpea rápido. Ella tiene las manos en mi pelo y me va guiando con una presión mínima, que se vuelve firme cuando encuentro el sitio donde su respiración cambia; y cuando la oigo decir "ahí, ahí" con la voz quebrada, entiendo que esa voz no la ha grabado nunca: no hay público, no hay ensayo, no hay segundo intento.*

*Le tomo la cadera con una mano y bajo el resto del cuerpo despacio, con la boca y con los dedos, hasta que ella arquea la espalda y la belleza de la habitación entera se reduce a la manera en que dice mi nombre tres veces seguidas, cada vez más bajo, y a la mano que me aprieta el hombro buscando un punto fijo. La sostengo ahí, sin prisa, hasta que el temblor le recorre las piernas y se le deshace en la garganta un sonido que ninguna cámara de este mundo va a capturar.*

MIKA: "Vale. Vale, vale, vale." *(sin aliento)* "Te toca a ti portarte peor."

NARRACIÓN: *Nos giramos. La cama protesta. Ahora está ella debajo, con el pelo repartido sobre la almohada y los ojos negros y abiertos, y me mira sin ninguna máscara — ni sonrisa preparada, ni ángulo, ni mirada de marca. Y esa mirada, es la recompensa completa de esta ruta: la de alguien que ya no está interpretando su propio placer, que solo lo siente.*

*La primera vez es de reconocimiento. Ella me guía con la mano y con la cadera, buscando el ángulo, y los dos nos reímos cuando no sale, y se ríe con la respiración partida, y luego ya no se ríe: se le corta la voz en la primera embestida y me clava las uñas en los omóplatos.*

MIKA: "Así. No pares. No—"

NARRACIÓN: *Y no paro. El ritmo deja de ser una decisión y pasa a ser una conversación: ella marca con las caderas, yo respondo, ella aprieta, yo espero, ella dice "más", yo doy más. El sudor, el crujido de la madera, la respiración de los dos llenando la habitación estrecha como si fuera una cocina en hora punta.*

*La segunda vez es de precisión: encuentro el ritmo que la desarma y lo sostengo, y ella deja de hablar y empieza a hacer ese sonido pequeño en el fondo de la garganta, y me toma la cara con las dos manos para que la mire.*

MIKA: "Mírame. Que quiero verte."

NARRACIÓN: *Y la miro. Y ella se rompe otra vez, más hondo que la primera, con las dos manos en mi cara y las piernas alrededor de mi cuerpo, diciéndome mi nombre contra mi boca como si fuera lo único que quedara en el idioma.*

*Después ya no puedo sostener nada: el placer me sube por la espalda y me deja en el filo, y ella lo nota, y me engancha con brazos y piernas como quien no piensa soltar, y me dice al oído, muy claro, con la voz ronca:*

MIKA: "Dentro. Confío en ti."

NARRACIÓN: *Y me dejo ir con la cara en su cuello, con su nombre en la boca, con el cuerpo entero temblando encima del suyo, y ella me abraza mientras se me pasa, con la mano abierta en mi espalda, contando las respiraciones como quien cuenta cucharadas.*

*La tercera vez, ya lo dije, es de risa.*

MIKA: "¿Puedo decir algo cursi?"

HIROSHI: "Por favor."

MIKA: "Nunca había estado con alguien que no me estuviera mirando como público. No sé hacerlo. Perdóname si me salió mal."

HIROSHI: "Te salió perfecto. Y de todas formas has mentido: hay uno mirándote."

MIKA: "¿Quién?"

HIROSHI: "Yo. Y no pienso apartar la vista."

NARRACIÓN: *Se ríe, con la cara escondida en mi cuello, y esa risa se le convierte en otra cosa, y luego en mi nombre dicho en voz baja, dos veces, tres veces, con la respiración partida.*

*Y así es como la chica que llevaba tres años perteneciendo a una audiencia pertenece, por una noche, a una sola persona.*

---
## ESCENA 11M.5 - LAS TRES CONVERSACIONES

NARRACIÓN: *Al día siguiente, pasa algo que ninguna novela visual enseña a manejar: la vida sigue. El sol entra por la ventana del taller como si nada, la Señora Tanaka manda un recado por el pescadero, y hay cebollas que cortar.*

*Pero en la cocina hay tres personas esperando su turno con Mika, y las tres lo han organizado entre ellas sin consultarme. Me entero porque Saki me pone una mano en el hombro al pasar y me dice, en un tono que no admite discusión:*

SAKI: "Hoy no te necesitamos, querido. Hoy te toca esperar en el comedor como los padres en una reunión de profesores."

HIROSHI: "¿Debería preocuparme?"

SAKI: "Deberías servir té. Hay tres tazas y la tuya."

### 11M.5.A — YUKI

NARRACIÓN: *La primera es Yuki. Se sienta frente a Mika con la espalda recta de siempre y las manos en las rodillas, y durante un minuto entero no dice nada. Mika espera. A estas alturas Mika ya sabe que el silencio de Yuki no es desprecio: es una persona ordenando ingredientes.*

YUKI: "Necesito decir una cosa antes de que se me desordene."

MIKA: "Dila."

YUKI: "No sé cómo se hace esto. Nunca he tenido... esto." *Mueve la mano señalando la cocina, la casa, todo.* "Tú fuiste la primera persona que me dijo que mi plato estaba bueno sin mirar cómo lo había cortado. Yo no quiero que eso se acabe."

NARRACIÓN: *Y ahí, Mika hace una cosa que no había hecho en todo el capítulo: se levanta de la mesa y se sienta al lado de Yuki. No enfrente. Al lado. Es un detalle pequeño y lo es todo.*

MIKA: "Yuki. ¿Puedo decirte una verdad que no le he dicho a nadie?"

YUKI: "Sí."

MIKA: "Tú eres mi hermana pequeña. Y eso no se elige — eso se celebra." *Y añade, con una sonrisa torcida, con la voz rota:* "Yo tuve una hermana mayor y me la quitaron. Así que esta vez no pienso dejar que se vaya nadie. Te vas a tener que aguantar."

NARRACIÓN: *Yuki Hayashi, dieciocho años, tres años de carrera profesional, una competencia perdida, una madre muerta y un plato que todavía no le sale bien, se echa a llorar como una niña.*

*Y Mika la abraza, y la abuela de las cebollas —que ha venido a traer el pedido y se ha quedado en la puerta— decide, con una discreción admirable, que hoy el pedido se lo lleva mañana.*

YUKI: "No entiendo por qué lloro."

MIKA: "Porque estás a salvo. Es lo que hace el cuerpo cuando por fin está a salvo."

YUKI: "Eso es muy poco científico."

MIKA: "Cariño, estás llorando en una cocina que huele a pollo. La ciencia se rindió hace dos calles."

---

### 11M.5.B — REN

NARRACIÓN: *La segunda es Ren, y con Ren la cosa va a ser por el otro camino: de frente y sin anestesia.*

REN: "¿Solo una cosa?"

MIKA: "¿Eh?"

REN: "Que si fue solo una cosa. El beso del festival. Porque si fue antes, os habéis pasado cinco meses de aquí a allá en el mismo taller y yo me he comido todas las cenas sin enterarme."

MIKA: "Ren—"

REN: "No lo digo como ataque. Lo digo porque yo también tengo lo mío y quiero saber el orden de las cosas. Odio los bordes mal definidos. Un cuchillo mal afilado estropea el corte y no se nota hasta que está servido."

NARRACIÓN: *Mika la mira un segundo largo. Y luego hace un gesto de rendición: se sube a la encimera de la cocina, se sienta con las piernas cruzadas y le da una palmada al sitio de al lado.*

MIKA: "Sube. Esto se cuenta sentada."

NARRACIÓN: *Ren sube. Con la dignidad de quien no se sube nunca a las encimeras, y se sube.*

REN: "Estoy escuchando."

MIKA: "Antes del festival, nada. Palabra. Después del festival... todo. De golpe y por la puerta grande. Y sí, fue confuso, y sí, he tardado en contarlo, y no me arrepiento de haber tardado porque no estaba entera. ¿Contento?"

REN: "Medianamente."

MIKA: "Bueno. Pues ahora te toca."

REN: "¿El qué?"

MIKA: "A ti. Lo tuyo. Ren Takahashi no se sienta en una encimera a preguntar por un beso si tiene el corazón tranquilo."

NARRACIÓN: *Y ahí, Ren Takahashi hace algo que no le hemos visto hacer en once capítulos: hace el gesto de quien va a dar un dato profesional y se queda a mitad, con la boca abierta, sin dato.*

REN: "Vine aquí porque mi abuelo se murió, mi familia me culpó, y un taller en un pueblo que no sale en los mapas era el único sitio del país que no tenía historia mía dentro." *Pausa.* "Y ahora resulta que estoy en una encimera preguntándole a la dueña de mi jefa si le besó a alguien en el festival." *Pausa.* "No sé cuándo ha pasado esto, Nak—" *Se corrige.* "Mika. No sé cuándo dejó de ser un sitio donde esconderme y empezó a ser..."

MIKA: "¿Un sitio donde quedarte?"

REN: "Un sitio donde quedarme."

NARRACIÓN: *Silencio. Ren mira la pared.*

REN: "Y para que quede constancia: si estoy aquí no es por él. Es por el oficio, por la gente y por el pan de las seis de la mañana. Que no se te suba el triunfo a la cabeza."

MIKA: "Apuntado. ¿Abrazo?"

REN: "No te emociones."

NARRACIÓN: *Y Ren Takahashi baja de la encimera con toda la dignidad de su rango y deja que Mika la abrace un segundo. Cuenta hasta dos. Y luego, muy bajo, le dice al oído algo que no oigo. Y lo que sea que le dice hace que Mika se ría durante el resto del día.*

---
### 11M.5.C — SAKI

NARRACIÓN: *La tercera es Saki, y con Saki, no hay crisis: hay una clase magistral.*

*Se sientan las dos en el comedor con una botella de té frío que Saki trajo del mercado, y la conversación transcurre de una manera que a mí me deja leyendo el menú como un pasmarote desde la otra punta de la sala.*

SAKI: "Voy a ahorrarte una semana de ansiedad, cariño. No compites conmigo."

MIKA: "Eso no—"

SAKI: "Escucha. Yo tuve mi gran amor. Fue un restaurante. Me duró doce años, tenía las sillas grises y una clienta que pedía siempre el mismo plato con la misma queja. Lo perdí, y todavía lo digo así, ¿ves? Lo perdí, no lo dejé."

NARRACIÓN: *Un solo temblor. Lo veo desde aquí. Saki bebe té, se limpia con la mano y sigue.*

SAKI: "Cuando llegué a este pueblo, no venía a buscar sustituto de nada. Venía a ver si era capaz de volver a poner la mesa. Y vosotros me habéis puesto la mesa todos los días, con esas caras, con esas cebollas que cortáis tan mal—" *se interrumpe, señalando a Mika con el vaso* "—tú la peor."

MIKA: "¡Yo corto bien!"

SAKI: "Tú cortas rápido. Es distinto."

NARRACIÓN: *Y luego, bajando la voz, Saki dice lo importante, que lo llevaba preparado desde antes de sentarse:*

SAKI: "Así que quiero que sepas dos cosas. La primera: me quedo. Aquí, en el pueblo, en la escuela, en las comidas de los martes. La segunda: si algún día esto se rompe —y puede romperse, porque las cosas se rompen—, yo voy a poner la mesa igual. Que no se te olvide con quién estás trabajando."

NARRACIÓN: *Mika se queda un momento en silencio. Y luego hace lo que hace siempre que no sabe qué decir: la abraza.*

SAKI: "Querida, me vas a arrugar la blusa."

MIKA: "Te compro una nueva."

SAKI: "Es de mi tía. Mejor no la compres y suéltame."

NARRACIÓN: *Y así, con tres conversaciones que nadie habría podido guionizar, se cierra el pacto que sostiene toda esta ruta: nadie se va. Ni la rechazada, ni la dudosa, ni la que ya tuvo su gran amor.*

### CIERRE DE ESCENA — LA MESA DE LOS CINCO

NARRACIÓN: *Esa noche cenamos en la mesa grande, con el mantel de cuadros que compramos en el mercadillo la primera semana.*

*Yuki trae un plato nuevo —una prueba, sin nombre todavía—. Ren se queja del punto de la carne y se la come entera. Saki sirve el té en el orden incorrecto a propósito, para que Ren la corrija y ella la corrija a ella.*

*Y Mika, cuando ya estamos todos, levanta el vaso. Sin marco, sin lente, sin foco rojo.*

MIKA: "Por nosotros."

HIROSHI: "Por nosotros."

YUKI: "Por nosotros."

REN: "Por el pan de las seis."

SAKI: "Por el pan de las seis."

NARRACIÓN: *Y bebemos, y en ese brindis cabe todo: un pueblo que casi se murió, un taller que era un local abandonado con sábanas sobre las mesas, y cinco personas que se conocían desde hacía cinco meses y que ahora no sabrían existir de otra manera.*

---


## ESCENA 11M.6 - CIERRE DE CAPÍTULO

NARRACIÓN: *A la mañana siguiente, Mika se sienta en la barra con el cuaderno donde hace las listas y escribe un título arriba de una página en blanco.*

*Leo por encima del hombro:*

*"COSAS QUE QUIERO CONTAR. SIN CÁMARA."*

*Y debajo, en letra pequeña, la primera entrada:*

*"1. Que la comida de este pueblo es la mejor del mundo y lo vamos a demostrar."*

*Deja el lápiz. Mira la página. Y sonríe.*

MIKA: "¿Sabes qué es lo raro? Llevo tres años teniendo una audiencia. Y este cuaderno es la primera cosa de mi vida que he escrito solo para mí."

HIROSHI: "Guárdalo bien."

MIKA: "Pienso."

NARRACIÓN: *Lo guarda en el cajón de la cocina, debajo del delantal de trabajo, entre las cucharas y los papelillos de receta de Saki.*

*En algún lugar de este pueblo hay un local que ya no tiene sábanas sobre las mesas, y una mujer que ha dejado de grabarse para que la quieran.*

*Y yo voy a ayudarla a contar lo que sigue.*

PRÓXIMO: Capítulo 12M - "El Estreno"

---

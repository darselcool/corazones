﻿## CAPÍTULO 10M: ESTO NO HA TERMINADO

---

## ESCENA 10M.1 - LOS ARCHIVOS

NARRACIÓN: *El ataque no llega por la mañana. Llega a las once de la noche de un martes cualquiera, que es como llegan todos los ataques de verdad: cuando ya he bajado la guardia y estoy contando las ollas para mañana.*

*Estamos cerrando el taller. Ren barre. Saki hace cuentas en voz baja, que es su manera de tararear. Yuki desengrasa su cuchillo con la devoción de un sacerdote y su reliquia.*

*Y de pronto Saki deja de leer números.*

SAKI: "Mika. Ven aquí. Ahora."

NARRACIÓN: *Hay tonos de voz que funcionan como cuchillos de aviso: no cortan, pero anuncian que alguien, en algún lugar, va a terminar cortado. Saki acababa de usar uno.*

*El vídeo tiene veinte minutos y lleva seis horas en línea. Se llama LA VERDAD SOBRE MIKA NAKAMURA — por la Dirección del Canal. La miniatura es Mika, de hace tres años, riendo con esa risa que yo aprendí a distinguir de la verdadera porque le faltaba el final.*

*Kenji no sale en el vídeo. Kenji nunca sale en los vídeos. Solo su voz, cálida como un contrato, montada sobre imágenes de archivo.*

*Y las imágenes son de Mika. Pero no de la Mika de ahora — de la Mika de antes. La de los vídeos que ella grababa mirando a un punto fijo por encima del hombro de la cámara, como si conversara con alguien sentado justo detrás de mí.*

NARRACIÓN: *Porque conversaba. Ya lo sabíamos. Lo que no sabíamos — lo que el mundo entero acaba de descubrir con seis horas de ventaja sobre nosotros — es que el archivo completo del canal incluye esas grabaciones. Las que Mika nunca publicó. Las que estaban "sin difundir" porque no eran producto.*

*La descripción del vídeo dice: "material de archivo inédito, compartido con amor para honrar el legado de nuestra querida Mika en este momento difícil".*

YUKI: "'Momento difícil'." *La voz de Yuki es plana como una lámina de acero bien templada.* "Ella está perfectamente bien. Ese es el problema del que no tiene remedio el señor del canal."

REN: "Cuatro millones de visitas." *Ren no levanta la vista del teléfono, y eso en Ren es la señal máxima de furia contenida: Ren, que mira a la gente a los ojos como quien empuña.* "En seis horas. Cuatro millones de personas han visto la máscara."

MIKA: "Cinco."

NARRACIÓN: *Nos volteamos. Mika está en la puerta del almacén, con la charola de las notas del día en la mano, mirando su propio reflejo en la vitrina oscura.*

MIKA: "Cinco millones. Yo también sé leer contadores. Tres años de práctica."

NARRACIÓN: *Y ahí está la grieta de esta escena: el pueblo también está viendo el vídeo. El pueblo que nos respalda, el pueblo que formó muralla — viendo, ahora, cada gesto falso de la máscara, cada rizo forzado, cada "¡hola, mis amores!" que ella misma nos contó que le costaba dos intentos y una náusea.*

*Saki cierra el portátil con el suave toque de quien cierra un ataúd.*

SAKI: "Mañana llega su abogado a las diez. Trae los contratos pendientes firmados en digital. Kenji los renovó el mes pasado, cuando ella aún—"

MIKA: "Cuando yo aún era su chica de la máscara, sí. Dilo entero, Saki. En este taller no hay nada de lo que yo haya hablado que no se pueda repetir en voz alta. Esa es la regla que yo misma pedí."

NARRACIÓN: *Y entonces Mika hace algo que ninguno de los cinco esperaba.*

*Se sienta en el banco de la esquina, el bueno, el de la ventana, y pide prestado el delantal de Ren, y desengrasa la plancha con una calma que no me gusta precisamente porque sí me gusta: es su versión de mi cocina-para-callar, y la reconozco enseguida porque es la mía.*

MIKA: "Mañana será lo que sea. Esta noche, alguien tiene que dejar la plancha brillante para el desayuno del pueblo. Yo me ofrezco. Vayan a dormir."

NARRACIÓN: *Nadie va a dormir. Todos fingen ir. Es lo que hace esta familia: fingir retiradas mientras quedan de centinelas.*

*Yo soy el último centinela. Me quedo.*

---

## ESCENA 10M.2 - EL PARQUE

NARRACIÓN: *A las dos de la mañana, la plancha brilla y Mika no está.*

*No hay drama en su ausencia: el delantal de Ren doblado sobre la mesa, sus zapatos cambiados por las sandalias viejas, las que usa "para pensar". El pueblo tiene tres lugares para pensar y yo solo necesito uno para adivinarla: el parque. La banca. La que da a la calle principal, donde un autobús pasa tres veces al día.*

*Llego despacio. No es una escena de persecución. Es una escena de acompañamiento, y uno no llega al acompañamiento corriendo.*

*Se oye el río. Se oye un lejano perro. Se oye, sobre todo, el silencio de ella, que es más grande que los otros dos juntos.*

*No digo nada. Me siento.*

NARRACIÓN: *La banca de 3.2. La misma. Yo ya la conocía de fama antes de sentarme en ella esta noche: es donde Mika venía a hablar con una hermana que ya no puede contestar, y ahora entiendo por qué siempre se sienta siempre del lado izquierdo, porque en el derecho hay espacio para alguien que ya no lo ocupa.*

*Contamos autobuses juntos. Pasan dos. Ninguno es el nuestro.*

MIKA: "Se llamaba Akari."

NARRACIÓN: *Y con ese nombre, que en 9M.4 ya había roto el agua como una piedra, ahora llega todo el resto del río.*

MIKA: "Akari Nakamura. Mi hermana mayor. La persona más sabia que he conocido, y lo digo con autoridad porque conocí a la Señora Tanaka." *No le sale la risa. Lo intenta y no le sale, y eso, viniendo de ella, es más elocuente que cualquier llanto.* "Akari dibujaba pueblos. Nunca vivimos en uno — vivimos en la ciudad, en un apartamento donde el ruido nunca bajaba del volumen seis. Pero ella dibujaba pueblos. Calles con una sola parada de bus. Tiendas con dueñas que te conocían el nombre. Un día dibujó uno con un mercado pequeño y una anciana en la puerta, y le puso por título 'el lugar donde sí'. Yo no entendí el título. Yo tenía catorce años y entendía pocas cosas que no cupieran en una pantalla."

*Se queda callada un rato largo. Yo también. Hay silencios que se comparten como un plato: cada uno toma de su lado.*

MIKA: "Se enfermó cuando yo tenía diecinueve. Lo lento. Lo de meses. Lo de salas de espera donde aprendí a odiar el olor del desinfectante y a leer la cara de las enfermeras antes que sus palabras." *Respira.* "Y en una de esas noches, en el hospital, aburrida de que yo le llevara revistas que no le gustaban, me pidió lo único que ella quería: 'Grábame vídeos, Mika. Grábale el mundo. Grábale el mar, que yo no llego. Grábale la gente. Para que no se me pierda.'"

NARRACIÓN: *Y ahí lo supe todo de golpe, porque un relato es un cuchillo que solo corta cuando llega completo a la mesa.*

MIKA: "Los primeros fueron buenos. El mar le gustó. La gente le gustó. Los editaba en el pasillo del hospital con el celular y ella los veía con los audífonos y cerraba los ojos y decía 'ese soy yo, guárdalo'. Y yo los guardé todos. Los guardé tanto que un día un algoritmo me descubrió, y un día un productor me descubrió, y un día Kenji me descubrió, y el canal pasó de 'para Akari' a 'para el mundo', y nadie me avisó de que en ese camino el mundo se comía a Akari."

MIKA: "Murió esperando un amanecer que le prometí grabar y nunca grabé. Estaba tan cansada, y yo estaba tan ocupada con la gira de promoción de un vídeo que era suyo..." *La voz se le quiebra con educación, como alguien que pide perdón al interrumpirse.* "Nunca dije su nombre en el canal. Kenji decía que 'dolía el branding'. Tres años, Hiroshi. Tres años diciendo 'mi familia' en plural y bajando la voz, porque el duelo no era difundible."

*El río. El perro. Ningún autobús.*

MIKA: "Ya no tenía a quién darle el mundo, así que me di al mundo. Y me perdí."

NARRACIÓN: *Y ahora me toca a mí. Porque hay heridas que no se atienden con consejos, y heridas que no se atienden con silencio, sino con la otra persona bajándose la suya también.*

HIROSHI: "Yo tuve un Kenji bueno."

NARRACIÓN: *Mika levanta la vista.*

HIROSHI: "Se llamaba igual que tu productor, y nunca sé si eso me hace reír o me hace encender la plancha dos veces. Me enseñó todo lo que sé de cocina, y me enseñó, sobre todo, que la cocina sirve a las personas y no a las cuentas de los inversores. Cuando expuse la corrupción de mis antiguos socios, él habría estado orgulloso. No lo pudo ver. Murió antes. Y un chico que seguía mis consejos — un aprendiz brillante, veintidós años, creía en lo que yo decía sobre hacer lo correcto — me lo repitió como un mantra y el mundo lo premió destrozándolo, y un día ya no estaba para cocinar nada. Nunca más."

NARRACIÓN: *Se me queda mirando. Y con la elegancia de los que han tocado fondo de verdad, no me pregunta cómo murió. Pregunta lo que importa:*

MIKA: "¿Y por eso viniste? ¿A este pueblo que ella dibujó y que tú no conocías?"

NARRACIÓN: *Y ahí está el milagro de la estadística: de todos los pueblos pequeños de la prefectura, el autobús me dejó en el único que Akari Nakamura había dibujado para su hermana. No lo supe hasta hoy. No lo podía saber.*

HIROSHI: "Vine huyendo. Y aterricé, sin saberlo, en el lugar donde sí. Creo que a veces el mundo es mejor arquería que nosotros: apunta por los dos."

MIKA: "Eso fue cursi."

HIROSHI: "Completamente cursi."

MIKA: "No lo corrijas. Lo necesito cursi hoy."

NARRACIÓN: *Le paso el brazo por los hombros y ella deja la cabeza donde cae, y así contamos un tercer autobús, que tampoco es el nuestro, y por primera vez desde que la conozco, el silencio de Mika pesa menos que el mío.*

*[El pueblo entero se entera al alba. La escena 10M.3 es la del alba.]*

---

## ESCENA 10M.3 - LA RESPUESTA DEL PUEBLO

NARRACIÓN: *El alba en Sakura-machi es un asunto discreto: primero se aclaran las montañas, después el río, y al final la calle principal, como si hasta el sol entendiera la jerarquía del lugar.*

*A esa hora, la Señora Tanaka ya está de pie frente al mercado con los brazos cruzados, que es su pose de guerra. Con ella están doce abuelas, Jiro, el pescadero, y un bache de gente que crece como sube la marea: en cuarenta minutos ya somos medio pueblo, y a las ocho, todo el pueblo.*

*Todos hemos visto el vídeo. Todos hemos visto la máscara.*

*Y todos, han llegado a la misma conclusión al mismo tiempo, que es lo que ocurre cuando un pueblo pequeño lleva cuatro generaciones practicando la lectura de rostros: la máscara es la noticia, no el escándalo. Nadie está aquí por el escándalo.*

SRA. TANAKA: "La reunión es a las diez, cuando llegue el abogado ese. Pero el desayuno es ahora, y es gratis, y es en el taller de esos chicos, porque quiero verle la cara al mundo cuando el mundo sepa que esta muchacha nos cocina desde que llegó."

NARRACIÓN: *La señora de la blusa impecable señala a Mika, que se ha quedado en la puerta del taller con una charola de tazas y la cara de quien asiste a su propio funeral y descubre que es una fiesta.*

ABUELA DEL MERCADO: "Yo sabía que algo pasaba cuando dijo '¡hola, mis amores!' la primera vez que entró al mercado. A nadie se le dice 'mis amores' tan bien sin práctica y tan triste sin motivo." *Se encoge de hombros.* "Además, compraba las berenjenas y las ponía en la mochila con cuidado de que no se magullaran. Los malos no cuidan las berenjenas."

NARRACIÓN: *Risas. Y aquí viene lo que ni Kenji ni cuatro millones de visitas podían calcular: el vídeo que pretendía exhibir a Mika, la máscara, la falsa risa, tiene el efecto exactamente inverso en un pueblo que la conoce de primera mano.*

*Porque el pueblo ya ha visto lo otro. Lo real. Lo de la muralla frente a la van.*

*Jiro sube al escalón del mercado. Jiro tiene ochenta y dos años y una columna que cruje como piso de madera vieja, y nunca ha subido a un escenario en su vida, porque esto no es un escenario, es un escalón, y esa es toda la diferencia.*

JIRO: "Buenos días. Soy Jiro Nakamura." *Pausa. El pueblo aguanta la respiración: nadie ha oído decir el apellido de Jiro en voz alta jamás.* "Y quiero aclarar algo para las personas de afuera que estén viendo: en este pueblo hay más Nakamura de los que aparecen en papeles. Esa muchacha lleva meses cocinándonos, cuidándonos y escuchándonos. Yo no tengo hijos. A partir de hoy tengo una nieta y no acepto objeciones. Y nadie usa el apellido de esta familia solo."

NARRACIÓN: *Mika suelta las tazas en la charola con un golpe de loza que le sale al corazón. Yo cuento por lo menos cuatro abuelas sacándose pañuelos de lugares imposibles.*

*Y entonces Saki se adelanta con su portátil y su voz de contratos, y hace lo que Saki hace: transformar la rabia en cláusulas.*

SAKI: "Tengo dos noticias. La mala: la amenaza legal del desarrollador Watanabe seguía activa y esta mañana intentó anclarse a este escándalo — la petición llegó a las siete y cuarto, con adjetivos como 'inestabilidad social'." *Pausa quirúrgica.* "La buena: la Sra. Tanaka y las abuelas me autorizaron a abrir el archivo de recetas familiares del pueblo, y con los contactos de la oficina de patrimonio de la prefectura — que me deben favores desde el juicio de mi tío — esta mañana misma hemos iniciado el registro del archivo culinario de Sakura-machi como patrimonio cultural local."

NARRACIÓN: *Silencio. El bueno. El de la maquinaria pesada cambiando de marcha.*

SAKI: "Un pueblo con un archivo culinario registrado no se toca con centros comerciales. Un pueblo con un archivo registrado no se toca, punto. Los inversores retiran el proyecto esta misma semana; lo aseguro no porque sea optimista, sino porque lo he leído tres veces y la tercera vez ya me aburría."

NARRACIÓN: *Y ahí se cierra el frente del Sr. Watanabe: no con un portazo, que es como entran, sino con un memorando, que es como salen los que pierden contra papeles bien atados. El viernes llega una carta con membrete de abogados: "renuncia amistosa al proyecto", y ni siquiera se molestan en venir a despedirse. Los burocratas tampoco tienen tiempo para las derrotas propias.*

*El frente de Saki: cerrado. En esta rama, nadie vuelve a mencionar el centro comercial jamás.*

---

## ESCENA 10M.4 - LA REUNIÓN DE LAS DIEZ

NARRACIÓN: *El abogado de Kenji llega a las diez y doce minutos en un auto que huele a aire acondicionado nuevo. Trae el portafolio de cuero y la sonrisa de quien cobra por hora y por sonrisa.*

*Trae, sobre todo, los contratos.*

ABOGADO: "Tres contratos vigentes con la señora Nakamura. Cláusula de exclusividad, cláusula de imagen, cláusula de no difusión de contenidos no autorizados. El canal tiene derecho a publicar material de archivo, incluido el material interno, conforme a la—"

SAKI: "Conforme a la cláusula novena, que exige consentimiento expreso por escrito para cualquier material donde aparezcan terceros sin acuerdo de imagen. Las cintas del hospital tienen un tercero. Se llama Akari Nakamura. Está muerta. Me imagino que su cliente querrá evitar el capítulo de esa demanda, porque yo ya tengo el escrito a medio redactar y me sobra mañana."

NARRACIÓN: *El abogado se traga la sonrisa. Es un trago duro, se ve.*

*Y entonces la reunión, que iba a ser un asunto de cláusulas, se convierte en lo que Kenji no había previsto: una asamblea. Porque el abogado habla de Mika. Y el pueblo entero está ahí, y el pueblo entero habla ahora también.*

*Es la Sra. Tanaka quien pone el dedo en el centro exacto del asunto, como pone el dedo en la primera hogaza del día:*

SRA. TANAKA: "Aquí hay un malentendido de bulto. Ustedes creen que la muchacha les pertenece porque la filmaron mucho tiempo. Nosotros sabemos que no, porque la conocemos poco tiempo y nos basta. Esa es toda la diferencia entre ustedes y nosotros, y es una diferencia de matemática simple: ustedes tienen contratos. Nosotros tenemos testigos."

NARRACIÓN: *El abogado mira a su alrededor. Nos mira: a Ren, con los brazos cruzados; a Yuki, con el cuchillo de cocinar en el cinturón y la mirada en otro lugar — porque Yuki no está aquí para esto, y aun así está; a Saki, que ya abrió el portátil otra vez.*

*Y al final nos mira a Mika y a mí. A Mika, que no ha dicho palabra en diez minutos.*

ABOGADO: "¿Y usted qué dice, señora Nakamura? Al fin y al cabo, los contratos son con usted."

NARRACIÓN: *Mika se pone de pie. Se arremanga el delantal. Y mira al abogado con la mirada de la Mika de ahora, la que ya no teme, y le dice la frase que yo sé que va a terminar citada en el documental que todavía no sabemos que vamos a hacer:*

MIKA: "Dígale a su cliente que tendrá su respuesta. Mañana. En el puente del río, a las siete de la tarde, delante de todo el pueblo. Que traiga cámara. Es lo último que le voy a dar."

NARRACIÓN: *Se hace el silencio. Y con el silencio llega, la pregunta que se me clava a mí — que a quién le toca saltar a la piedra — y que me toca responder entera:*

*[¿Quién debe enfrentar a Kenji mañana? La respuesta cambia la ruta del Capítulo 10M entero.]*

---

## ELECCIÓN 3M:

**OPCIÓN A: "Yo. Mañana yo hablo con él. A él no lo enfrenta una víctima: la táctica es que enfrente a alguien que no le teme."**
- Hiroshi toma el frente. El pueblo respalda en silencio.
- `[Escena 10M.5-A: Hiroshi lo confronta solo — victoriosa pero fría; a Mika le quitan su propia escena. Sin CG 04.]`

**OPCIÓN B: "Ella. Mañana ella lo enfrenta. Con la cámara encendida. Nadie va a dar esta respuesta por ella: esa es exactamente la razón por la que tiene que ser ella."**
- Mika parpadea una sola vez. Y luego, muy despacio, sonríe con la mitad de la boca que siempre ha sido la verdadera.
- `[CAMINO VERDADERO — desbloquea CG 04 y la escena extendida de 10M.5.]`

**OPCIÓN C: "Saki. Mañana esto se resuelve con papeles, no con discursos. Déjame a mí y a Saki terminar la obra."**
- Saki asiente, agradecida de que alguien por fin lo diga en voz alta.
- `[Escena 10M.5-C: vía legal — papeles, no catarsis. Sin CG 04.]`

> **Nota de producción:** las tres resuelven el frente Kenji — el pago de la amenaza "esto no ha terminado" ocurre sí o sí. Solo la Opción B lo convierte en la escena de poder invertido y desbloquea la escena íntima de la noche.

---

## ESCENA 10M.5 - EL PUENTE (CAMINO VERDADERO — OPCIÓN B)

> **Nota de producción:** escena escrita para la Opción B (camino verdadero). Las variantes A y C se resumen al final de la escena.

*Siete de la tarde. El puente del río está lleno como para una boda, y de hecho, me guardo este detalle para dentro de cuatro capítulos: de esta gente, hoy, viene casi toda la lista de invitados.*

*Kenji llega puntual, que es lo único puntual que ha hecho en esta historia. Trae una cámara al hombro — la enciende, porque ella se lo pidió y él cree que aún obedece protocolos de ella.*

KENJI: "Mika. Cariño. Te dije que esto no había terminado, y mira, aquí estamos. Un minuto más y—"

MIKA: "Empecemos. Una pregunta, y luego las demás vienen solas: ¿cómo se llamaba la chica de las cintas del hospital?"

NARRACIÓN: *Kenji parpadea. Es lo primero que le sale humano en tres años: un parpadeo.*

KENJI: "Perdona, ¿el qué?"

MIKA: "El material que publicaste anoche. El 'legado'. En una de esas cintas hay una chica sentada en un pasillo de hospital editando vídeos con un celular a las tres de la mañana. ¿Cómo se llamaba esa chica? Porque yo la conocía y no la encuentro en tu vídeo. En tu vídeo solo está la marca."

NARRACIÓN: *Y aquí ocurre la inversión de poder, la que provoca esta elección: porque Kenji llegó con una cámara para filmar a una víctima, y descubre que está dentro de una entrevista. Que la cámara que él mismo encendió va a grabar, con su propio pulgar en el botón, cada palabra de lo que sigue.*

MIKA: "Pregunta dos: en los contratos, ¿en qué año se quitó la cláusula que me permitía rechazar contenido? Pregunta tres: ¿cuántas veces firmaste tú por mí los 'permisos de ubicación' de la casa de mi hermana? Pregunta cuatro—" *Y la voz no se le quiebra: baja, que es peor.* "¿Cuánto pagaban por 'la Mika sonríe siempre'?"

NARRACIÓN: *El pueblo no dice nada. No hace falta. El río dice de todo con el ruido de siempre.*

*Kenji mira la cámara. Kenji mira al pueblo. Kenji mira, por un segundo que dura un expediente entero, a su propio abogado — y el abogado le devuelve la mirada de quien ya calculó el capítulo de la demanda y no le gusta el número.*

KENJI: "Eso... eso se negocia. Mika, cariño, todo se negocia—"

MIKA: "Sí. Se negocia. Saki tiene los papeles." *Se le acerca la sonrisa entera, la verdadera, la de la mitad que no se practica.* "Y yo tengo algo mejor que papeles: te tengo grabado. Con tu cámara. Que ya es mi cámara, porque todo lo que graba es mío, ¿verdad? Eso decían los contratos."

NARRACIÓN: *Y ahí lo apaga ella. El foco rojo muere con un clic pequeñito que, prometo, suena más fuerte que los cuatro millones de visitas.*

*La maquinaria de Saki pega el golpe de gracia en el descanso: los contratos mueren por vicios de consentimiento y por la cláusula novena, y la demanda de la cláusula novena muere antes de nacer porque Kenji, de repente, prefiere la anulación mutua y la no repetición. Los que viven de las cámaras saben, mejor que nadie, lo que es ser filmado.*

*Kenji se va caminando junto al río, con la cámara al hombro y vacía, y nadie le dice "esto no ha terminado". En Sakura-machi las despedidas son mejores que las amenazas: no dicen nada. Solo se vuelven a sus cocinas.*

*[Variantes: OPCIÓN A — Hiroshi confronta a Kenji solo: el abogado capitula igual, pero Mika recibe su victoria de segunda mano y la noche de las luciérnagas ocurre sin la escena extendida. OPCIÓN C — vía Saki: los papeles hacen lo suyo en una sala fría, sin público, sin catarsis, sin beso. La historia continúa igual en los tres casos; solo cambia quién sostiene la cámara de su propia vida.]*

---
## ESCENA 10M.6 - LA NOCHE DE LAS LUCIÉRNAGAS (CAMINO VERDADERO)

NARRACIÓN: *El pueblo se vacía como se vacían los pueblos: sin anuncio. Las familias recogen a los niños a las ocho y media porque mañana hay escuela, los jóvenes se van en grupos hacia la plaza porque en la plaza siempre pasa algo, y el río se queda con el puente y con nosotros.*

*Casi con nosotros.*

MIKA: "Tengo una regla nueva. Regla número... la que sea. Los días en los que te ganas a ti misma frente a tu antiguo jefe, se celebran."

REN: "Comulgamos esa regla."

YUKI: "¿En qué consiste la celebración?"

MIKA: "Todavía no lo sé. Pero requiere caminar. Y requiere que nadie lleve cámaras."

NARRACIÓN: *Saki es la primera en darse la vuelta hacia el taller, que es un gesto de diputada: tiene papeles que ordenar, cláusulas que descansar. Ren dice que va a revisar los cuchillos, que no hay que revisar los cuchillos, y se va a revisarlos igual. Yuki se queda un minuto más, mirando a Mika como se mira un problema de geometría que de repente se volvió sencillo.*

YUKI: "Estabas bien hoy."

MIKA: "Estaba aterrada."

YUKI: "..." *Los hombros suben y bajan: la versión de Yuki de un abrazo, con veinte por ciento más de generosidad del gramo habitual.* "Lo cual significa que estabas bien. Mañana te explico la diferencia. Hiroshi, llévala al río. Los del campo dicen que este año han venido temprano."

MIKA: "¿Los qué?"

YUKI: "Las luciérnagas. ¿En qué planeta vives?"

NARRACIÓN: *Y se va, con su chaqueta de chef y su precisión de reloj suizo, dejándome a mí la logística de la celebración y a Mika la expresión de quien acaba de recibir un regalo envuelto en catorce palabras.*

*Camino al río bajo, donde el sendero se aparta del puente y el pueblo deja de tener farolas. Mika camina como camina ahora, desde hace un tiempo: sin buscar el ángulo. Antes apuraba los pasos, como si la vida la esperara en el próximo plano. Ahora se nota cuando se detiene a oler algo. Lo noto porque llevo meses aprendiéndomelo, aunque la palabra exacta para esto todavía no me la he dado a mí mismo.*

MIKA: "¿Sabes qué es lo raro? Llevé tres años de vida profesional sin un solo día libre sin contenido. Un día libre, para mí, era un día en el que el contenido se grababa solo. Y hoy me gané un día entero. Un día que no se va a ver en ninguna parte."

HIROSHI: "Lo veo yo."

MIKA: "Tú no cuentas."

HIROSHI: "No. No cuento."

NARRACIÓN: *Y ahí se para. Y se gira. Y la luz que queda del día le viene de lado, la mitad de la cara encendida y la mitad en sombra, que es la foto que ella jamás se haría, porque las mitades no venden.*

MIKA: "Hiroshi. La nota de ayer decía una mentira. Lo escribí y lo dejé ahí a propósito, porque si lo escribo y tú no dices nada, es solo un pensamiento; y si lo escribes tú, es una promesa."

*No lleva la cámara. El huesito de la memoria va en el bolsillo de mi chaqueta desde el alba, porque me lo dio ella después del festival y no me lo ha pedido de vuelta. Le pasó por la cabeza. Se le notó pasarle por la cabeza, en el puente, cuando dijo 'es mío' mirándose los dedos.*

MIKA: "La nota decía que esto no tiene nombre. Mentira. Tiene nombre. Lleva semanas teniendo nombre, solo que yo vengo de un mundo donde los nombres se publican con contrato y letra pequeña, y a veces tarda uno en creerse que puede decir uno en voz alta algo que no va a venderse."

NARRACIÓN: *Las primeras luces llegan entonces, como llegan: de a una, ajenas al ritmo humano, sin permiso. Una sobre el agua. Otra sobre el junco. Otra encima de la mano de ella, que no se mueve.*

MIKA: "Mira."

HIROSHI: "Te veo."

MIKA: "No. Mira—"

HIROSHI: "Te veo. Llevo dos meses diciéndotelo en un idioma que no es el tuyo. El tuyo es este."

*Y me acerco el suficiente.*

NARRACIÓN: *El beso es de las luciérnagas: sin espectadores, sin guion, sin segunda toma. Ella huele a azúcar quemada y a río y a noche de junio, y ríe en medio, porque es ella, y la risa se le mete en el beso y de ahí no sale ya nunca.*

MIKA: "Uy." *(contra mi boca)* "Eso iba a decirlo yo."

HIROSHI: "Dilo tú también. Quiero oírlo con tu acento."

MIKA: "Te elijo. Sin cámara, sin contrato, sin letra pequeña. Te elijo en el idioma de las cosas que no se pueden ver, que es el único que sé que es de verdad."

NARRACIÓN: *Cien luciérnagas, más o menos, dan testimonio de lo que no se puede ver. Ninguna firma acuerdo de imagen.*

---

## ESCENA 10M.7 - NOTA DEL DÍA

*(Última escena del capítulo — pantalla oscura, el pliego amarillo en primer plano.)*

**MIKA (v.o.):** *"Nota del día: hoy aprendí que el valor de una escena no lo mide el número de espectadores. Lo midió el temblor de una mano cuando apagó una cámara. — Mika. En el río, bajo las luciérnagas, sin testigos que importen."*

NARRACIÓN: *El foco rojo de una cámara encendida jamás volvería a darle miedo. Pero eso, ya es la historia del siguiente capítulo — porque hay cosas que se cierran afuera y cosas que apenas ahora empiezan a abrirse adentro.*

`TONO: renacer. PRÓXIMO: Capítulo 11M — "Sin Máscara".`

---




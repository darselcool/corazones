﻿# CORAZONES EN EBULLICIÓN

## CAPÍTULO 13M: LA PREGUNTA (RUTA MIKA)

---

## ESCENA 13M.1 - CARTA DE TOKIO

NARRACIÓN: *La carta llega un martes, en un sobre con membrete de la prefectura, y la trae el cartero que lleva treinta años subiendo la misma cuesta y que ese día sube corriendo.*

CARTERO: "¡Esto es para el taller! ¡Ha llegado una carta certificada!"

MIKA: "¿Certificada? ¿Quién manda cartas certificadas en este siglo?"

CARTERO: "La prefectura. He visto el logo y he subido corriendo. Llevo treinta años sin subir esta cuesta corriendo."

NARRACIÓN: *Abrimos el sobre sobre la mesa grande, con los cinco alrededor, como se abren las cosas importantes en este pueblo: con todo el mundo mirando y nadie tocando.*

*Y dentro está lo que Mika llevaba tres semanas sin atreverse a esperar: la carta de selección del Festival de Cine Documental de la Prefectura.*

MIKA: "Estamos seleccionados."

YUKI: "¿En la sección oficial?"

MIKA: "En la sección oficial."

NARRACIÓN: *Y se produce, el caos más hermoso que he visto en esta cocina: Yuki da una palmada y se queda con las manos en el aire como si no supiera qué hacer con ellas; Ren dice "bien" con una voz que no le sale; Saki dice "voy a hacer la comida del viaje" y desaparece hacia el almacén; y Mika se queda sentada, con la carta en las manos, sin moverse, mirándola.*

HIROSHI: "¿Estás bien?"

MIKA: "Estoy aterrada."

HIROSHI: "¿Por qué?"

MIKA: "Porque van a ver la película en una sala con butacas. Con críticos. Con gente que escribe." *Pausa.* "Con gente como la que me hizo los tres contratos."

NARRACIÓN: *Y ahí hay un silencio, porque todo el mundo está pensando lo mismo: que la última vez que Mika se subió a un escenario delante de gente que escribe, salió con un contrato firmado que tardó cuatro años en poder romper.*

*Y entonces habla Ren, sin levantar la vista del cuchillo que está afilando.*

REN: "Si alguno de esos escribe algo que no te guste, le mandamos al pescadero."

PESCADERO: *desde la puerta* "¿A quién hay que ir?"

REN: "A nadie, Manabu. Era un ejemplo."

PESCADERO: "Pues avisa, que me aburro."

### EL CANAL

NARRACIÓN: *Esa misma noche, Mika hace una cosa que llevaba meses sin hacer: abre su canal.*

*No el antiguo. El antiguo lo cerró en marzo, con un vídeo de once minutos que ya no existe y que explicaba, sin nombrar a nadie, por qué se iba. Este es otro. Se llama, simplemente, su nombre: **MIKA NAKAMURA**.*

*Y sube un vídeo de cuatro minutos: el tráiler del documental, sin música, sin logos, sin patrocinio. Al final, un cartel escrito a mano que dice:*

*"Subo cuando quiero. Es mío."*

NARRACIÓN: *A la mañana siguiente tiene nueve mil visitas. A la semana, cuarenta mil. Y una única pregunta repetida en los comentarios que Mika lee en voz alta en la cocina con una sonrisa extraña:*

MIKA: "'¿Por qué no monetizas esto?'" *Ríe.* "Porque puedo pagar el alquiler con la escuela, señor algoritmo. Y porque si monetizo, dentro de seis meses tengo que subir un vídeo que no quiero hacer."

REN: "¿Y eso no te da miedo?"

MIKA: "Me da pánico. Pero es un pánico mío. Eso es distinto."

### LA NOTICIA DEL RESTAURANTE

NARRACIÓN: *Y el mismo día, entre las noticias del sector que Saki lee todas las mañanas en el móvil mientras desayuna, aparece una que hace que la cocina se quede en silencio.*

*La lee Saki, en alto, sin cambiar de tono. Sólo que deja la taza en la mesa antes de empezar, y eso ya es un aviso.*

SAKI: "Restaurante Tsuki, Tokio. Pérdida de la segunda estrella. El chef responsable lleva dos años en el puesto tras la salida de su predecesor."

NARRACIÓN: *Y nada más. Lo deja ahí, sobre la mesa, como se deja un pescado fresco: para que cada cual lo cocine a su manera.*

*Y ahí estoy yo, con una taza de té en la mano, mirando las letras de la noticia, y descubriendo una cosa que no me esperaba: que no siento absolutamente nada.*

MIKA: "¿Hiroshi?"

HIROSHI: "Estoy bien."

MIKA: "Te has quedado quieto."

HIROSHI: "Es que estoy bien. De verdad." *Dejo la taza.* "Durante dos años pensé en ese sitio. En el menú, en la gente, en lo que habrían hecho con la sala. Pensé en volver. Pensé en escribir una carta pidiendo explicaciones. Pensé en montar un restaurante aquí, en el pueblo, sólo para demostrar que sin mí aquello se caía."

*Pausa.*

HIROSHI: "Y hoy me entero de que se ha caído, y lo único que siento es que ya no cocino para demostrar nada."

NARRACIÓN: *Mika me mira un momento. Y luego hace lo que hace ella: convierte el momento en una pregunta pequeña, de las que no parecen importantes y lo son.*

MIKA: "¿Y para qué cocinas ahora?"

HIROSHI: "Para que la gente se siente. Para que vuelvan. Para el martes."

MIKA: "Eso es muy poco ambicioso."

HIROSHI: "Es lo único que he querido en toda mi vida y he tardado treinta y siete años en poder decirlo."

---

## ESCENA 13M.2 - EL CUCHILLO DE KENJI

NARRACIÓN: *Hay una cosa que llevo desde el Capítulo 1 sin hacer. Una sola. Y no es cocinar. Es hablar.*

*El cuchillo de Kenji duerme en el cajón del fondo, envuelto en un paño que ya no huele a nada. Lo he sacado muchas veces. Nunca lo he usado en esta cocina. Lo he afilado, lo he limpiado, lo he dejado sobre la tabla y lo he vuelto a guardar, como quien toca la foto de alguien y la deja en su sitio.*

*Hoy lo pongo sobre la mesa grande, a plena luz del mediodía, con Mika sentada enfrente y la cocina vacía.*

MIKA: "Es ese, ¿verdad?"

HIROSHI: "Es ese."

MIKA: "El que sale en el Capítulo 1."

HIROSHI: "¿Tú cómo sabes que sale en el Capítulo 1?"

MIKA: "Porque me contaste la historia tres veces, Hiroshi. Una borracho, una a las cuatro de la mañana, y una el día que hicimos las galletas. Y las tres veces empezaste por el cuchillo." *Se inclina.* "Lo que nunca me contaste fue el final."

NARRACIÓN: *Y ahí está. La cosa que llevo tres años sin decir en voz alta.*

*Saco la tabla. Saco el cuchillo del paño. Y empiezo por lo de siempre, porque lo de siempre es lo que sé.*

HIROSHI: "Kenji fue mi maestro. No me enseñó a cocinar, eso lo aprendí antes. Me enseñó lo otro. Me enseñó a limpiar una cocina cuando estás destrozado. Me enseñó que un plato no se termina hasta que está la salsa, y que la salsa no se termina hasta que está la mano quieta."

MIKA: "La mano quieta."

HIROSHI: "Si te tiembla la mano, la salsa te sale cobarde."

MIKA: "Eso es una frase suya."

HIROSHI: "Todo lo bueno que digo es una frase suya." *Corto la cebolla.* "Dijo una vez que el talento es la parte fácil. Que lo difícil es aguantar el martes."

MIKA: "El martes."

HIROSHI: "El martes del mes treinta y cuatro. El martes que llevas cuatro años cocinando y nadie te escribe. Ese martes. Decía que ahí se ve quién es cocinero."

NARRACIÓN: *El cuchillo entra en la cebolla como si llevara diez años esperando esto. Corto, sin pensar, con la mano quieta.*

MIKA: "¿Cuánto tiempo llevas sin contarle esto a nadie?"

HIROSHI: "Nunca se lo he contado a nadie."

MIKA: "¿Ni a las chicas?"

HIROSHI: "Saben que existe. Saben que está muerto. No saben lo demás."

MIKA: "¿Y por qué a mí?"

NARRACIÓN: *Y ahí es donde me paro. Porque la respuesta es sencilla y no la he dicho nunca en voz alta, y hoy es el día.*

HIROSHI: "Porque tú preguntas. Yuki no pregunta, intuye. Ren no pregunta, respeta. Saki no pregunta, espera." *Pausa.* "Tú preguntas. Y me obligas a buscar la frase. Y a veces la frase no la tengo hasta que la digo."

MIKA: "Eso es lo más bonito y lo más inconveniente que me han dicho nunca."

HIROSHI: "Es tu culpa por preguntar tanto."

NARRACIÓN: *Mika ríe. Y esa risa hace que pueda seguir.*

HIROSHI: "Un martes, hace unos diez años, Kenji no vino a abrir. Vivíamos a dos calles. Fui, tenía la llave porque me la había dado para regar las plantas cuando viajaba."

*Corto los ajos. Uno. Dos. Tres.*

HIROSHI: "Lo encontré sentado en la cocina. Con una taza delante. Y una nota."

MIKA: "Hiroshi—"

HIROSHI: "No la leí. Nunca la he leído. La dejé en la mesa y llamé a una ambulancia que ya no hacía falta." *Dejo el cuchillo.* "Y llevo diez años preguntándome si la nota decía algo que yo tenía que haber oído."

NARRACIÓN: *Silencio. La cebolla se dora en la sartén a fuego lento y llena toda la cocina. Y Mika hace lo que sabe hacer: no me consuela.*

MIKA: "¿Te la habría dicho a ti?"

HIROSHI: "No lo sé."

MIKA: "Yo sí."

NARRACIÓN: *Levanto la vista.*

MIKA: "Si hubiera querido decírtelo, te lo habría dicho. Escribir una nota no es contárselo a alguien. Escribir una nota es no contárselo a nadie." *Pausa.* "Hiroshi, mi hermana me escribió seis cuadernos. Seis. Y con todo lo que escribió, hay una cosa que nunca me escribió: que se estaba muriendo. Lo supe por la enfermera. Y durante dos años pensé que me había mentido."

MIKA: "No me mintió. Estaba intentando hacer lo que hacía Kenji. No es una mentira, es una manera de no cargarte con eso."

NARRACIÓN: *Y yo ahí, con una cebolla a medio dorar y un cuchillo de diez años en la mano, descubro de golpe la cosa más importante de los últimos tres años.*

*Que la culpa no era por no haber leído la nota.*

*La culpa era por no haberle preguntado.*

HIROSHI: "Él no me pidió cargar el mundo."

MIKA: "No."

HIROSHI: "Me pidió cocinar."

MIKA: "Eso es."

NARRACIÓN: *Y entonces hago la única cosa que se me ocurre, que es la única cosa que hay que hacer: empiezo a cocinar su plato.*

*No lo he hecho nunca. En diez años. Es lo único de su repertorio que nunca he tocado, porque hacerlo era admitir que ya no estaba. Nabeya. Un donburi de verduras y miso que él hacía los viernes, que no está en ningún libro, y cuya receta no está escrita en ninguna parte; sólo en el estómago de quien lo comió muchas veces.*

*Lo hago mal tres veces. La primera se me quema el miso. La segunda me queda salado, y me oigo decir en voz alta "está demasiado sazonado", y me río solo como un loco.*

*La tercera sale.*

MIKA: "¿Y bien?"

NARRACIÓN: *Pruebo. Y sabe exactamente como el viernes. Como los viernes de aquella cocina, con las ventanas abiertas y la radio puesta y un hombre mayor hablando de salsa mientras yo cortaba cebollas de forma lamentable.*

*Y no lloro. No sé por qué no lloro. Lo pruebo y no lloro.*

*Mika prueba, y sí llora.*

MIKA: "¿Le gustaba a Akari este plato?"

HIROSHI: "Este es de Kenji."

MIKA: "Pues ahora es de los dos."

NARRACIÓN: *Y ahí termina la cosa que llevaba diez años sin terminar.*

### EL PESO QUE NO SE PASA, SE PASA

NARRACIÓN: *Porque hay algo más. Y esto lo hace Mika, no yo.*

*En el documento del festival de la prefectura pone que cada película seleccionada puede tener una presentación de tres minutos antes del pase. Y Mika decide, sin consultarme, que la presentación la hago yo.*

HIROSHI: "Ni hablar."

MIKA: "¿Por qué no?"

HIROSHI: "Porque es tu película."

MIKA: "Es mi película y mi pueblo. Y tú eres mi cocinero." *Pausa.* "Que es otra manera de decir otra cosa, pero ya la diremos con las palabras correctas, ¿vale? Paso a paso."

NARRACIÓN: *Y entonces coge el cuchillo de Kenji de la tabla —con mi permiso, porque mira la tabla y luego me mira a mí, y yo asiento— y hace la única cosa que no esperaba.*

*Lo envuelve otra vez en el paño y lo deja en el cajón del fondo.*

MIKA: "Se queda aquí."

HIROSHI: "¿Y si lo quiero llevar?"

MIKA: "Entonces lo coges. Pero dejas de dejarlo encima de la tabla en mitad de una escena."

NARRACIÓN: *Y me doy cuenta de que tiene razón. Llevo tres años dejando ese cuchillo en el centro de la cocina como se deja la foto de un muerto en el aparador: no para usarla, sino para que alguien pregunte.*

*Alguien ha preguntado.*

*Ya no hace falta el aparador.*

HIROSHI: "Vale."

MIKA: "Vale."

HIROSHI: "Pero el día del festival sí lo llevo."

MIKA: "El día del festival sí. Y lo usas para cortar algo y se te va a caer una lágrima y voy a grabarlo."

HIROSHI: "No vas a grabar nada."

MIKA: "No, no voy a grabar nada." *Sonríe.* "Pero me lo voy a acordar, que es peor."

---

## ESCENA 13M.3 - LA PROPUESTA (ELECCIÓN FINAL)

NARRACIÓN: *Y así, llegamos al día del festival de la prefectura. Y a la cosa que llevo tres semanas preparando por la espalda de Mika Nakamura, que es difícil de hacer porque Mika Nakamura se entera de todo.*

*El anillo lo ha hecho Ren.*

NARRACIÓN: *Fue idea suya, además. Vino una noche a la cocina con un paño y una balanza pequeña, y me lo puso encima de la mesa sin decir nada.*

REN: "Se te ha ocurrido algo y no sabes cómo."

HIROSHI: "¿Se me nota tanto?"

REN: "Se te nota cuando afilas. Afilas cuando piensas."

NARRACIÓN: *Y sí, es verdad. Afilo cuando pienso. En fin.*

*Sacó el paño. Dentro había un trozo de plata que reconocí de inmediato: era uno de los mangos de las campanas de plata de la familia Yamamoto, cortado y vuelto a fundir.*

HIROSHI: "Ren. Eso es de las campanas."

REN: "Era de las campanas. El badajo no. Sólo un trozo del mango, y Saki lo autorizó." *Pausa.* "Dijo que su padre habría querido que la plata de las campanas siguiera haciendo ruido en algo."

HIROSHI: "No sé qué decir."

REN: "No digas nada. Dime el dedo y las medidas."

NARRACIÓN: *Y esa es Ren. Lleva seis capítulos haciendo joyas de plata para la boda de otra persona y presentándolo como un trámite.*

---

### ELECCIÓN 7M: LA PROPUESTA

NARRACIÓN: *El festival se celebra en el centro de la prefectura, en un palacio de congresos con una sala de proyección de trescientas butacas. Nos han dado el pase de las seis de la tarde.*

*Y aquí llega la decisión que llevo cuatro capítulos esperando. La propuesta la hago hoy. La decisión es dónde.*

**OPCIÓN A — "En la cena, delante de todos."**
*La pido después del estreno, en la cena de celebración, delante de las tres y de medio pueblo.*
`[Escena 13M.4-A. Tono: público, celebratorio, con las tres como testigos y el pueblo estallando. CG 12-alt "La familia aplaude".]`

**OPCIÓN B — "En el escenario, delante de trescientas personas."**
*Espero a los tres minutos de presentación. En vez de presentar la película, presento otra cosa.*
`[Escena 13M.4-B. Tono: teatral, vertiginoso, con Mika cubriéndose la cara delante de los críticos. CG 12-alt2 "Trescientas butacas de pie".]`

**OPCIÓN C — "En el parque. Reconstruyendo el dibujo."** `[VERDADERO]`
*A la mañana siguiente, antes de volver, la llevo a un parque de la prefectura que no es el parque del pueblo pero que tiene la misma banca, el mismo autobús de la línea circular y un mercado enfrente. Reconstruyo, puesto a puesto, la última página del cuaderno de Akari.*
`[Escena 13M.4-C. Tono: íntimo, devastador. CG 12 "El dibujo hecho realidad".]`

NARRACIÓN: *La diferencia, no está en el amor. Está en cuánto he escuchado. Si he escuchado lo suficiente, sé que hay una página concreta de un cuaderno que Mika no ha querido leerme nunca en voz alta, y sé por qué.*

*Esa página dice, con letra de niña de nueve años:*

*"EL SITIO DONDE MIKA SERÁ FELIZ: UNA BANCA, UN AUTOBÚS QUE PASA, Y UN MERCADO CON FRUTA. Y ALGUIEN QUE LE DÉ UN ONIGIRI."*

---

## ESCENA 13M.4 - LA RESPUESTA

### VARIANTE A — LA CENA

NARRACIÓN: *Si elijo la cena, la cosa sucede así: el estreno termina, la sala aplaude, el pueblo llora, y a las nueve estamos en una mesa larga de un izakaya de la prefectura con treinta personas que no caben y que se han sentado igual.*

*Espero al brindis. Y cuando todo el mundo levanta la copa, no brindo.*

HIROSHI: "Perdón. Voy a hacer una cosa que no es un brindis."

MIKA: "¿Hiroshi?"

NARRACIÓN: *Me arrodillo. Delante de treinta personas. Delante de Yuki, que se lleva las manos a la boca. Delante de Ren, que asiente una sola vez, satisfecha y profesional, como quien ve funcionar una máquina que montó él. Delante de Saki, que empieza a llorar antes que Mika.*

*Y ahí, Mika hace la cosa más Mika del mundo: se ríe.*

MIKA: "¡Hay treinta personas!"

HIROSHI: "Lo sé."

MIKA: "¡Mañana sale en el diario local!"

HIROSHI: "Que salga."

NARRACIÓN: *Y sí. Salió.*

### VARIANTE B — EL ESCENARIO

NARRACIÓN: *Si elijo el escenario, la cosa sucede así: son las seis de la tarde, hay trescientas butacas ocupadas, hay tres críticos en la fila cinco, y Mika me ha dado el micro con la cara de quien entrega un cuchillo a alguien que nunca ha cocinado.*

*Me presentan. Subo. Y tengo tres minutos.*

*Hablo dos minutos y medio del pueblo. De la escuela de Yuki, del centro de Mika, del mercado de Ren, del restaurante de Saki. De la gente que no sale en los créditos y que trajo sillas.*

*Y en el minuto dos y cuarenta segundos, me desvío.*

HIROSHI: "Y hay una última cosa. El pueblo no lo descubrí leyendo. Lo descubrí porque me lo contó una persona con una cámara rota."

NARRACIÓN: *En la fila siete, Mika Nakamura se hunde en la butaca.*

MIKA: *en un susurro que todo el mundo oye* "Hiroshi, no."

HIROSHI: "Mika. ¿Te quieres casar conmigo?"

NARRACIÓN: *Y trescientas personas —trescientas personas, incluidos tres críticos, un programador de festival y el alcalde de la prefectura— se ponen de pie al mismo tiempo.*

*Mika tarda ocho segundos en levantarse. Y cuando se levanta, dice la única cosa que podía decir:*

MIKA: "¡Me has robado el estreno!"

HIROSHI: "Sí."

MIKA: "¡Era MI estreno!"

HIROSHI: "Sí."

MIKA: *llorando y riendo a la vez* "Sí."

### VARIANTE C — EL PARQUE (VERDADERA)

NARRACIÓN: *Y si he elegido el parque —si he escuchado de verdad—, la cosa sucede así:*

*Es la mañana siguiente. Los demás duermen en el hotel. Nos escapamos los dos, sin decir nada, con la excusa de comprar fruta para el viaje.*

*A diez minutos del palacio de congresos hay un parque pequeño que no es el parque de Sakura-machi. Pero tiene la misma banca gris al principio del paseo. El mismo autobús de la línea circular que pasa cada doce minutos. Y un mercado de barrio justo enfrente, con las cajas de fruta puestas en la acera porque no caben dentro.*

NARRACIÓN: *Y yo he traído, tres cosas en una bolsa de tela. Las tres son importantes. Ninguna es el anillo.*

*La primera es un cuaderno.*

*Se lo pongo en las manos sin decir nada. Mika lo mira, y en la portada, con rotulador, dice "AKARI — DIBUJOS", y debajo, en letra pequeña, hay una dedicatoria que le escribió a ella hace quince años.*

MIKA: "¿De dónde—"

HIROSHI: "Del estante de arriba de tu habitación, en el pueblo. La caja que no abres."

MIKA: "Esa caja es—"

HIROSHI: "Sé lo que es esa caja." *Pausa.* "Y sé que hay una página que no me has leído nunca."

NARRACIÓN: *Silencio. El autobús pasa. Mika abre el cuaderno por el final, por donde se abren los cuadernos que se conocen de memoria, y encuentra la página.*

*Y no lo lee en voz alta. Le basta con verlo.*

MIKA: "¿Cómo...?"

HIROSHI: "Porque una noche, en marzo, me hablaste dormida."

NARRACIÓN: *Y ahora la segunda cosa.*

*Saco de la bolsa de tela un onigiri. Envuelto en un trozo de papel de periódico, mal envuelto, con las esquinas a la vista.*

MIKA: "¿Qué es eso?"

HIROSHI: "Un onigiri."

MIKA: "Hiroshi, hay un mercado justo ahí. Puedo comprarme un onigiri perfecto en cualquier—"

HIROSHI: "No es perfecto."

NARRACIÓN: *Lo abro. Y Mika se queda sin habla, porque el onigiri está quemado. No un poco. De un costado entero, negro, con esa forma que tiene la comida cuando lleva cinco minutos de más a fuego alto porque quien lo hacía estaba llorando y no miraba.*

MIKA: "Está quemado."

HIROSHI: "Lo he hecho seis veces. Las cinco primeras no estaban bastante quemadas."

MIKA: "¿Qué?"

HIROSHI: "La página dice 'alguien que le dé un onigiri'. No dice alguien que le dé un onigiri bueno." *Pausa.* "Yo cocino bien, Mika. Llevo veinte años cocinando bien. Y lo que le prometo a tu hermana no es una cosa bien hecha. Es que cuando te salga mal, voy a comerme igual la parte quemada."

NARRACIÓN: *Y Mika Nakamura, con un cuaderno de su hermana en una mano y un onigiri quemado en la otra, se sienta en la banca gris. Y yo me arrodillo en el suelo, no delante de ella, sino al lado.*

MIKA: "Si te arrodillas ahí, vas a parecer un loco."

HIROSHI: "Ya lo parezco. Llevo tres capítulos pareciéndolo."

NARRACIÓN: *Y saco la tercera cosa.*

*El anillo es pequeño, de plata, con el pulido ligeramente irregular de una pieza hecha a mano. Y tiene una marca interior, un grabado diminuto que Mika descubre girándolo, porque el anillo gira solo cuando lo mira, y en la parte de dentro pone:*

*"EL MARTES."*

MIKA: "¿Qué es 'el martes'?"

HIROSHI: "Lo difícil no es el talento. Lo difícil es aguantar el martes." *Pausa.* "Y yo quiero todos tus martes."

NARRACIÓN: *El autobús pasa otra vez. Doce minutos exactos. Ese es todo el tiempo que tarda Mika en extender la mano, sin decir sí, con los dedos separados, mirando el anillo como se miran las cosas que uno no se atreve a tocar.*

MIKA: "¿Es de las campanas?"

HIROSHI: "Sí."

MIKA: "Lo ha hecho Ren."

HIROSHI: "Lo ha hecho Ren."

NARRACIÓN: *Y lo dice en voz alta, con una voz rara, y luego añade la cosa más Mika de la escena entera:*

MIKA: "Está un poco torcido."

HIROSHI: "Está un poco torcido."

MIKA: "Me encanta que esté un poco torcido."

NARRACIÓN: *Y sí.*

*Sí.*

---

## ESCENA 13M.5 - LA NOCHE DEL COMPROMISO (EXPLÍCITA)

NARRACIÓN: *Volvemos esa tarde. Cuatro horas de autobús por la carretera de la montaña, con Saki conduciendo el último tramo y Yuki dormida contra la ventanilla, y Mika y yo en la última fila sin hablar, con su mano en la mía y el anillo girando entre sus dedos cada vez que se le olvida que lo lleva.*

*Y llega la noche. Y la habitación de arriba del mercado, que tiene una cama individual, un escritorio simple y una ventana que da a la calle principal.*

*Y, esta noche Mika hace una cosa antes de nada.*

*Enciende la cámara.*

MIKA: "Espera."

NARRACIÓN: *Se sienta en el borde de la cama, saca la cámara pequeña del bolso, la enciende y la coloca sobre el escritorio, apuntándole a la cara. El foco rojo parpadea.*

MIKA: *mirando al lente, con una voz que no es la suya de creadora de contenido, sino otra, más baja, más de verdad* "Akari. Soy yo."

*Pausa.*

MIKA: "Me voy a casar. Con el cocinero. El del pueblo que dibujaste."

*Pausa.*

MIKA: "Voy a ser feliz. Voy a ser feliz de verdad, y no de la que se cuenta. De la del martes." *Se le rompe un poco la voz.* "Te quería contar esto en persona. Como no se puede, lo dejo grabado. Ya está."

NARRACIÓN: *Y apaga la cámara.*

*No la borra. La deja sobre el escritorio y la gira hacia la pared, con el lente contra el yeso, y se queda un momento mirándola de espaldas como se mira a alguien que ya se va.*

MIKA: "Ya está."

HIROSHI: "¿La vas a subir?"

MIKA: "No."

HIROSHI: "¿La vas a borrar?"

MIKA: "No."

HIROSHI: "¿Entonces?"

MIKA: "Entonces se queda ahí. En mi cajón. Para mí." *Pausa.* "Lo demás no se comparte."

NARRACIÓN: *Y ahí, entiendo la frase entera de la ruta. No es que Mika haya dejado de grabar. Es que ha aprendido a distinguir lo que se comparte de lo que se vive. La cámara no es el enemigo: es una puerta que ahora tiene cerradura, y la llave la tiene ella.*

*Se levanta. Y se queda a un paso de mí, con las manos a los lados, sin tocarme, esperando —y aquí está la diferencia con la primera noche, aquí está todo—sin esperar nada.*

*La primera vez, en la habitación del hotel, tuvimos que descubrirnos. Teníamos que quitar capas: la máscara de ella, la culpa mía, las palabras que nunca habíamos dicho. Fue torpe a ratos y fue hermoso por eso.*

*Esta vez no hay capas.*

*Esta vez nos sabemos.*

NARRACIÓN: *La beso despacio, sin prisa, con una mano en su mejilla y la otra en su cintura. Y ella me responde igual, midiendo, saboreando, con los dedos en mi nuca y la respiración ya cambiada antes de que ninguno de los dos haya dicho nada.*

*Le bajo la cremallera del vestido con dos dedos y le ayudo a salir de él, y el vestido cae al suelo con un ruido suave. Se queda en ropa interior, de pie, delante de mí, y por primera vez en toda la ruta no se tapa, no bromea, no dice nada gracioso.*

*Solo me mira, y espera.*

MIKA: "Dime si quieres parar."

HIROSHI: "Eso lo digo yo."

MIKA: "Lo sé. Pero yo también quiero poder decirlo." *Media sonrisa.* "Es mi primera vez estando segura de todo. Quiero hacerlo bien."

HIROSHI: "Te diría."

MIKA: "¿Qué?"

HIROSHI: "Que si quieres parar, te lo diría. Y que no quiero."

NARRACIÓN: *Y la levanto en brazos y la llevo a la cama, que es individual y nos viene pequeña, y ella se ríe contra mi cuello diciendo que vamos a caernos, y nos caemos, y nos reímos, y luego dejamos de reírnos.*

*Le quito el sujetador despacio, por la espalda, y ella arquea la espalda hacia mí, y entonces sí, entonces la descubro entera: la piel morena de sus hombros, la cicatriz diminuta sobre la clavícula que me contó una vez que se hizo a los doce años con un trípode, los pechos pequeños y firmes, la respiración que se le corta cuando paso la palma por el vientre.*

MIKA: "Ahí no."

HIROSHI: "¿Por qué?"

MIKA: "Porque me muero." *Pausa.* "Sigue."

NARRACIÓN: *Y sigo.*

*Con la boca, primero, bajando por su cuello y por el esternón y deteniéndome en el pecho, y ella enreda los dedos en mi pelo y dice mi nombre de una forma que no le había oído nunca, corta, sin aire. Le muerdo apenas el pezón y siento cómo se le tensa todo el cuerpo debajo de mí, cómo se le cierra una mano en la sábana y la otra en mi hombro.*

MIKA: "Hiroshi."

HIROSHI: "¿Demasiado?"

MIKA: "No. No pares. Si paras, te mato."

NARRACIÓN: *Bajo más. Le quito la última prenda por las caderas, despacio, y ella levanta la pelvis para ayudarme, y cuando la tengo delante entera, desnuda sobre la sábana blanca de la habitación del mercado, la luz de la luna entrando por la ventana, hay un segundo en el que los dos sabemos que esto es distinto.*

*Porque la primera noche fue un descubrimiento. Esta es una confirmación.*

*Y la confirmo.*

NARRACIÓN: *La beso ahí, sin avisar, y ella da un respingo entero y luego una risa ahogada y luego ya no risa.*

*Es lenta. Es lenta porque quiero que sea lenta, porque tengo todo el tiempo del mundo y quiero gastarlo, y porque cada vez que ella está a punto de alcanzar algo yo me detengo y la dejo respirar, y ella me insulta en voz baja con una palabra que no le había oído a nadie nunca.*

MIKA: "Eres horrible."

HIROSHI: "Soy paciente."

MIKA: "Es lo mismo."

*Y le paso los dedos por dentro, despacio, uno primero, y ella se agarra a mi antebrazo y arquea la espalda y dice "ahí" y luego "otra vez" y luego ya no dice palabras.*

*Y cuando la siento tensarse entera, cuando la respiración se le rompe y se le escapa un sonido que no es palabra y que le sale del centro del pecho, la sostengo, la sostengo con la mano libre en su vientre, sin dejar de moverme, hasta que se le pasa, hasta que se le afloja todo el cuerpo y se queda jadeando con los ojos cerrados y las mejillas mojadas y la boca abierta en una sonrisa tonta que no se ve pero se siente en la voz:*

MIKA: "Vale. Vale, vale, vale."

HIROSHI: "¿Vale?"

MIKA: "Vale. Perfecto. Ya está. Ya no puedo más."

NARRACIÓN: *Y entonces ella abre los ojos, y en vez de dejarse ir, hace la cosa que la define: se gira, me empuja del pecho con las dos manos, y me tira sobre la espalda.*

MIKA: "Ahora tú."

HIROSHI: "Mika—"

MIKA: "He dicho ahora tú."

NARRACIÓN: *Se coloca encima, a horcajadas, con las manos en mi pecho y el pelo cayéndole por la cara, y se queda así un momento, sin moverse, mirándome, con el anillo brillando en la penumbra, y me dice la cosa que va a ser el centro de mi vida a partir de esta noche:*

MIKA: "Quiero verte."

HIROSHI: "¿El qué?"

MIKA: "Todo. Quiero verte todo."

NARRACIÓN: *Y se baja despacio, tomándome con la mano, guiándose, y me siento entrar en ella centímetro a centímetro, y ella aprieta los labios y arquea la espalda y hace un ruido pequeño al llegar hasta el final.*

*Y luego se queda quieta. Con los ojos cerrados. Respirando.*

MIKA: "Espera. Espera un segundo."

HIROSHI: "Todo el tiempo que quieras."

NARRACIÓN: *Y así estamos un rato largo, yo dentro de ella, ella encima de mí, los dos quietos y respirando, con la calle vacía de Sakura-machi al otro lado de la ventana y las campanas de plata colgadas en la pared de la cocina de abajo.*

*Y antes de empezar a moverse, hace la cosa que me descoloca entero.*

MIKA: "Espera. Una cosa más."

HIROSHI: "Lo que quieras."

NARRACIÓN: *Se queda quieta encima de mí, con los ojos cerrados, respirando. Y cuando los abre tiene la cara que pone cuando va a decir la verdad y le da miedo.*

MIKA: "¿Sabes qué día es hoy?"

HIROSHI: "El miércoles."

MIKA: "No. Del mes." *Se muerde el labio.* "Del ciclo."

NARRACIÓN: *Y ahí, me quedo sin aire por una razón completamente distinta a la de hace dos minutos.*

MIKA: "Doce."

HIROSHI: "Mika—"

MIKA: "Escúchame antes de decir nada. Me he preparado el discurso en el autobús y lo voy a decir mal igual, pero lo voy a decir." *Respira.* "Llevo doce días contando. En la libreta. La del cajón. La que uso desde los quince años. La que llevaba al hospital cuando acompañaba a mi hermana, porque ahí aprendí que las cosas importantes llegan sin avisar y que lo único que puedes hacer con ellas es apuntarlas."

*Pausa.*

MIKA: "Hoy estoy en mis días. Los buenos. Los que el cuerpo está pidiendo."

*Y se calla. Y me mira.*

*Y yo, hago lo único que sé hacer: preguntar.*

HIROSHI: "¿Y qué quieres?"

MIKA: "Quiero que no te salgas."

NARRACIÓN: *Lo dice del tirón, rápido, como se tira de una tirita.*

MIKA: "Quiero que acabes dentro. Todo. No un poco, no a medias, no fuera. Dentro." *Y luego, más bajo, con una voz que solo he oído en esta habitación:* "Quiero que lo dejes dentro y que se quede ahí. Quiero... quiero estar llena, Hiroshi. Toda la noche. Todo el mes. Todo lo que haga falta. Quiero tu semilla."

*Pausa. La luna. La calle.*

MIKA: "Llevo un mes esperándolo. Todo el mes. Y no te he dicho nada porque quería decírtelo aquí, hoy, con el anillo puesto y contigo dentro. Y porque si me lo pensaba un día más se me iba a pasar la ventana y luego tendría que esperar otro mes entero, y yo ya no quiero esperar meses. Llevo cuatro años esperando meses."

HIROSHI: "Mika, esto no es una noche."

MIKA: "Lo sé."

HIROSHI: "Esto es para siempre."

MIKA: "Lo sé." *Y se le llenan los ojos.* "¿Y tú crees que me da miedo? Llevo cuatro años queriendo algo que fuera para siempre y mirándolo desde fuera. Ahora lo tengo debajo de mí y me pides que piense en el lunes."

HIROSHI: "No te pido que pienses. Te pregunto si estás segura."

MIKA: "Estoy segura." *Y lo dice con la voz entera, sin broma, sin máscara, sin nada.* "Estoy segura de una cosa por primera vez en mi vida, y es esta."

HIROSHI: "Entonces hay algo que quiero que sepas yo también." *Le subo las manos a la cara.* "No te voy a dar un hijo. Te voy a dar todos los que quieras."

MIKA: *una risa que se le rompe a medio camino* "¿Sabes que es lo más bonito que me han dicho nunca? Y me lo acabas de decir conmigo sentada encima. Eres un desastre."

HIROSHI: "Soy tuyo."

MIKA: "Eso también."

*Y entonces empieza a moverse.*

*Despacio primero, buscando el ritmo, las manos apoyadas en mi pecho, hasta que lo encuentra: una cadencia lenta y larga, de arriba abajo, con la espalda arqueada y la respiración que se le va cortando en cada bajada.*

*Y yo la sigo, con las manos en sus caderas primero y luego en su espalda, y luego sentándome para besarla mientras nos movemos, y ella me abraza el cuello y me muerde el labio y luego echa la cabeza atrás y se mueve más fuerte.*

MIKA: "Hiroshi—"

HIROSHI: "Aquí."

MIKA: "No pares. No pares, no pares."

NARRACIÓN: *Y no paro.*

*Y la cosa se acelera, y deja de ser lenta y deja de ser bonita y se vuelve urgente, y yo la agarro por la cintura y la ayudo a moverse, y ella llega antes que yo, la segunda vez, con un grito que ahoga contra mi hombro, mordiéndome la camiseta—*

*—y no me suelta.*

NARRACIÓN: *No me suelta. Le tiemblan los muslos y se le afloja la espalda y aun así se clava hacia abajo hasta el fondo y se queda ahí, con las rodillas apretadas alrededor de mis caderas y los tobillos cruzados en mi espalda, y me aprieta, me encierra dentro con el cuerpo como se cierra una puerta con llave.*

MIKA: "Dentro. Dentro, dentro—"

HIROSHI: "Mika—"

MIKA: "Todo. Todo dentro. No te salgas. No te sal-gas."

NARRACIÓN: *Y llego. Y no es como las otras veces, porque las otras veces había una parte de mí que ya estaba calculando el paso siguiente, la retirada, el gesto prudente. Esta noche no hay retirada. Esta noche me aprieto contra ella hasta el fondo y me quedo ahí, con las dos manos abiertas en su espalda y la cara hundida en su pelo, y la siento abrirse y cerrarse alrededor en el mismo instante en que empiezo a derramarme dentro.*

*Es largo. Es más largo de lo que recuerdo, y no es sólo el cuerpo: es que ella lo siente, y lo sabe, y lo dice.*

MIKA: "Ahí. Ahí. Siento cómo... siento todo, Hiroshi, lo siento—"

NARRACIÓN: *Y se le escapa un sonido que no es palabra ni grito, un sonido bajo y largo contra mi oído, y me clava los talones en la espalda y se queda quieta, apretando, recibiendo, sin dejar escapar ni un centímetro.*

MIKA: "Quédate. No te muevas. No te muevas, por favor—"

HIROSHI: "No me muevo."

MIKA: "Ni un poco."

HIROSHI: "Ni un poco."

NARRACIÓN: *Y así nos quedamos. Un minuto entero, dos, no sé cuántos, yo todavía dentro de ella y ella todavía encima y los dos sin hablar, con la respiración volviendo poco a poco a su sitio. Siento cada latido suyo por dentro.*

MIKA: *al rato, con la voz rota* "¿Está... está todo dentro?"

HIROSHI: "Todo."

MIKA: "¿Seguro?"

HIROSHI: "Seguro."

MIKA: *y se ríe, y le sale una lágrima, y no la limpia* "Perdona. Es que esto es lo más guarro y lo más sagrado que he hecho en mi vida y no sé en qué orden ponerlo."

*CG 12c — "La libreta del cajón".*

NARRACIÓN: *Y después, viene la parte que nadie cuenta y que es la que importa: se tumba de espaldas sin dejar que me vaya, me agarra la muñeca para que me quede donde estoy, y se queda así, con las caderas ligeramente levantadas y las rodillas dobladas y una mano en su vientre por encima de mi mano.*

MIKA: "Diez minutos."

HIROSHI: "¿Diez minutos?"

MIKA: "Diez minutos. He leído cosas. Lo de las caderas." *Pausa.* "Es ridículo, lo sé."

HIROSHI: "No es ridículo."

MIKA: "Es un poco ridículo."

HIROSHI: "Es lo menos ridículo que has hecho nunca."

NARRACIÓN: *Y se queda así, mirando el techo de la habitación de arriba del mercado, con mi mano en su vientre y la suya encima, hablando en voz baja de cosas sin importancia —de la tortilla de mañana, de la carta a Tokio, del martes— mientras en algún sitio por dentro de ella, en un lugar que ninguno de los dos puede ver, empieza o no empieza una cosa que va a cambiar todas las demás.*

NARRACIÓN: *Y nos quedamos así un rato más. Derrumbados, con la cama individual crujiendo debajo, sudados, sin aire, con el anillo clavándome un poco en la nuca porque ella tiene la mano en mi nuca y el anillo está entre los dos.*

MIKA: "Me estás clavando."

HIROSHI: "El anillo."

MIKA: "El anillo." *Y se ríe, con una risa agotada, contra mi pecho.* "Toda la vida esperando esto y me clava."

NARRACIÓN: *Silencio. La luna. El autobús de las once pasando por la carretera alta, que desde aquí se oye lejísimos.*

MIKA: "¿Puedo decir algo cursi?"

HIROSHI: "Siempre dices algo cursi."

MIKA: "Sí. Pero hoy quiero permiso."

HIROSHI: "Permiso concedido."

MIKA: *un rato largo, en voz baja* "La viste venir y aun así dijiste sí."

HIROSHI: "¿El qué?"

MIKA: "Nada. Una tontería de un contrato viejo." *Pausa.* "Alguien me dijo una vez que yo era lo que se ve. Y yo me lo creí durante cuatro años." *Se levanta lo justo para mirarme a la cara.* "Y resulta que no. Resulta que lo que se ve era la mitad. Y tú eres la única persona que ha querido la otra mitad."

HIROSHI: "No es la otra mitad. Es la buena."

MIKA: "No digas eso."

HIROSHI: "Es la verdad."

MIKA: "Es la verdad y por eso no lo digas, que me voy a poner a llorar y ya he llorado bastante por hoy."

NARRACIÓN: *Se vuelve a tumbar encima de mí, con la cabeza en mi pecho, y se duerme en cuatro minutos, con el anillo en la mano, girándolo con el pulgar incluso dormida.*

*Y esa noche, hago una cosa que no hago nunca: no pienso. No repaso el menú del martes. No repaso la factura de la luz. No repaso nada.*

*Solo miro el techo de la habitación de arriba del mercado y escucho respirar a la mujer que ha dicho que sí, y me digo, por primera vez desde el Capítulo 1, una frase entera sin matizarla:*

*Voy a estar bien.*

### LA MAÑANA

NARRACIÓN: *Antes de bajar, la primera cosa que hace Mika Nakamura al despertarse no es mirarme a mí. Es abrir el cajón, sacar una libreta pequeña de tapas gastadas y rodear con un círculo la fecha de ayer, en una página donde hay veinte círculos iguales que nunca significaron nada y que a partir de ahora significan todo.*

*No me dice nada. La deja abierta encima del escritorio. A propósito. Para que yo lo vea.*

NARRACIÓN: *Y por la mañana, pasa la cosa que tenía que pasar.*

*Mika se levanta antes que yo. Y como tiene hambre y la cocina del taller está abajo y ella es Mika Nakamura, se pone la camiseta mía que había en la silla y se baja a cocinar con el anillo puesto.*

*Y a los veinte minutos me despierta el sonido más familiar de mi vida: un "ay" seguido de una sartén.*

NARRACIÓN: *Bajo. Y está delante de la estufa con una tortilla pegada a la sartén, el pelo hecho un desastre, mi camiseta hasta los muslos, y una cara de culpabilidad de niña de ocho años.*

MIKA: "No he dicho nada."

HIROSHI: "Se ha pegado."

MIKA: "Se ha pegado un poco."

HIROSHI: "Se ha pegado entera."

MIKA: "Es culpa del anillo."

NARRACIÓN: *Y ahí, con el sol entrando por las ventanas grandes del taller y una tortilla arruinada humeando entre los dos, hago la única cosa sensata que se puede hacer: le cojo la mano izquierda con dos dedos, le giro el anillo, y se lo paso al dedo medio.*

MIKA: "Es que en el anular me molesta."

HIROSHI: "En el anular molesta a todo el mundo el primer mes."

MIKA: "¿Y qué se hace?"

HIROSHI: "Se cocina mal un mes."

MIKA: "Eso es un precio muy alto."

HIROSHI: "Ese es el precio."

NARRACIÓN: *Y ella se queda mirándose la mano un momento, con el anillo mal puesto en el dedo medio, y luego coge la espátula y lo intenta otra vez, y se le vuelve a pegar, y los dos nos reímos hasta que se nos saltan las lágrimas.*

*CG 12b — "El anillo en el dedo equivocado".*

PRÓXIMO: Capítulo 14M - "El Corazón Auténtico"

---

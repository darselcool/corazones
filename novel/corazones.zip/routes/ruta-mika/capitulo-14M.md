# CORAZONES EN EBULLICIÓN

## CAPÍTULO 14M: EL CORAZÓN AUTÉNTICO (RUTA MIKA) — EPÍLOGO

---

## ESCENA 14M.1 - LA BODA

NARRACIÓN: *Hay una cosa que nadie me contó de las bodas de pueblo: que empiezan tres días antes.*

*Empiezan cuando Jiro aparece en el taller con una escalera y dice que las vigas hay que pasarlas con un trapo húmedo porque tienen cinco años de polvo de aceite, y que él no va a dejar que una novia se case debajo de eso. Empiezan cuando la Señora Tanaka decide que el menú no va a ser "de restaurante" sino de casa, y que para eso hay que pedirle a la pescadera del mercado que guarde lo mejor de tres mañanas seguidas. Empiezan cuando la mitad del pueblo se presenta sin que nadie la llame, con sillas plegables de su garaje y manteles de su abuela, y se reparten tareas que nadie organizó, y todo sale bien igual.*

*Y empiezan, sobre todo, cuando Ren Takahashi entra en el taller con una caja de madera y la deja sobre la mesa grande como quien deja un expediente.*

REN: "Ya está."

MIKA: "¿Ya está? ¿Qué es ya está?"

REN: "Las campanas."

NARRACIÓN: *Abre la caja. Dentro, sobre un paño oscuro, hay cinco campanas de plata. Cuatro son las que ya conocíamos —las de la familia Yamamoto, las que Saki recibió llorando la madrugada del festival del Capítulo 6—. La quinta es nueva. Más pequeña, del tamaño de una campana de viento, con el borde trabajado a mano y una media luna grabada en el costado.*

REN: "La quinta no existía. Las campanas Yamamoto eran cuatro porque eran cuatro hermanos. Así que le hice una a la familia nueva." *Se limpia las manos en el delantal, incómodo.* "Tardé cuatro meses porque no sé hacer campanas. Ahora sé hacer campanas."

SAKI: "Ren."

REN: "No me lo agradezcas, que me pongo rojo."

SAKI: "Iba a decirte que la media luna está torcida."

REN: "Está torcida a propósito."

SAKI: "Está torcida porque es tu primera campana."

REN: "Está torcida a propósito, Saki."

NARRACIÓN: *Y ahí, en esa discusión que no importa sobre una media luna de plata de dos milímetros, está la cosa entera. La familia. La elegida, la que nadie firmó, la que se queda.*

*Mika aparece en lo alto de la escalera del segundo piso con la cabeza envuelta en una toalla y los ojos hinchados de llorar por la razón más tonta del mundo: Yuki le ha dicho hace veinte minutos que el dobladillo del vestido de su madre está hecho con punto invisible y que ella lo puede copiar, y a Mika eso le ha parecido de repente lo más triste y lo más bonito del universo.*

MIKA: "¡¿Le habéis hecho una campana?!"

REN: "¡No se lo digas a nadie, que era una sorpresa!"

MIKA: "¡Sois horribles, me habéis hecho llorar otra vez!"

YUKI: *desde abajo, con una aguja en la boca* "Si bajas llorando te vas a mojar el dobladillo y lo vas a hacer otra vez. Y no lo voy a hacer otra vez."

NARRACIÓN: *Y es exactamente así —con Mika amenazando con tirarle una toalla a la cabeza a una chica de dieciocho años que habla con una aguja entre los dientes como una sastre de ochenta— que se casa la mujer con la que llevo un año.*

Familia.

---

NARRACIÓN: *El día es un martes.*

*Eso es importante y no lo es. Importante porque el pueblo entero llevaba seis meses esperando a que la novia eligiera, y ella eligió el martes de la primera semana de junio, sin ninguna razón, porque le pareció un día honesto. Y no importante porque, cuando llega el martes, da igual: la luz de junio entra por las ventanas grandes del taller —las mismas que descubrí polvorientas en el Capítulo 1, las mismas que pulí con un trapo durante cuatro tardes— y atraviesa todo el espacio como si el edificio llevara cien años esperando que alguien lo llenara de gente.*

*Cien personas. Quizá ciento veinte. No caben todas dentro y no importa: la mitad se queda en la calle, que el ayuntamiento ha cerrado sin que nadie lo pidiera, y los niños se sientan en la acera con trozos de tarta en las manos.*

NARRACIÓN: *Y hay una cosa más, que el pueblo entero sabe desde febrero y de la que nadie habla en voz alta, porque en Sakura-machi las cosas importantes no se anuncian: se cocinan.*

*Mika está embarazada de casi seis meses.*

*Se lo dijo a Yuki la primera. Fue en febrero, con la puerta de la cocina cerrada y las dos sentadas en el suelo, y Yuki —que tiene dieciocho años y una manera muy poco sentimental de querer a la gente— se levantó, fue a buscar la cinta métrica y dijo: "El dobladillo hay que hacerlo tres veces. Una por cada mes que te queda." Y lo hizo tres veces. La última, la semana pasada, a las once de la noche, con una aguja entre los dientes y sin decir una palabra más.*

*La Señora Tanaka lo supo antes que nadie, como sabe todo. No dijo nada. Al día siguiente el mercado abrió con una caja de melocotones en conserva que nadie había encargado y que la pescadera colocó en el mostrador sin preguntar. Eso, en Sakura-machi, es una felicitación.*

*Ren y Saki lo supieron de golpe, un domingo, en el taller. Saki me miró a mí primero, luego a Mika, durante cuatro segundos, y dijo: "¿De cuánto?" Y Mika dijo: "De dos meses y medio." Y Saki dijo: "Ya. Pues siéntate, que estás haciendo fuerza en la lumbar."*

*Yo no dije nada ese domingo. No me hacía falta. Ren me puso una mano en el hombro al salir y me dijo lo único que se puede decir: "Vas a ser muy bueno en esto." Y yo, que llevo media vida cocinando para gente que no conozco, me puse a llorar como un tonto en la puerta de mi propio taller.*

*Así que sí: el pueblo entero lleva seis meses esperando a la novia. Y la novia lleva seis meses esperando, además, otra cosa. Y hoy, las dos cosas se cumplen a la vez debajo de las mismas vigas.*

*Las sillas, prestadas de tres casas distintas, están puestas en dos filas mal alineadas. En la primera fila, muy seria, con el bolso en el regazo y el bastón apoyado en la silla de al lado, la Señora Watanabe. Sí, esa. Vino por Saki. Le dijo al pescadero que no venía a una boda "de provincias" y luego llegó la primera, a las nueve de la mañana, con un regalo envuelto en papel de periódico.*

*Jiro está en la puerta haciendo de acomodador sin que nadie se lo haya pedido. La Señora Tanaka, en la cocina, ha echado fuera a todos dos veces y está por echar a la tercera.*

*Ren espera a mi lado, con un traje que le sienta como si le hubieran puesto una trampa. Saki, en la cocina, con un delantal sobre un vestido que se puso para la ocasión y que lleva tres manchas de salsa ya. Y Yuki baja las escaleras en ese momento con el vestido de dama de honor que ella misma ha confeccionado —azul oscuro, corte sencillo, un dobladillo perfecto— y se coloca junto a la puerta, y me mira, y me hace un gesto de cabeza diminuto que significa "ya está, respira".*

HIROSHI: "¿Y si me equivoco de palabra?"

REN: "Te apuñalo."

HIROSHI: "Gracias."

REN: "Con cariño."

NARRACIÓN: *Y luego se hace ese silencio que hacen las bodas, que no es un silencio sino el mundo entero aguantando la respiración, y suena la primera campana.*

*Saki, desde la puerta de la cocina, con la campana de los Yamamoto en la mano.*

*Una.*

*La segunda suena Ren, desde mi lado. La tercera, Yuki. La cuarta, la Señora Tanaka, que sale de la cocina con un paño en el hombro y la toca como quien llama a la gente a la mesa.*

*Y la quinta —la torcida— la toca Jiro, en la puerta, con las dos manos, como toca el anciano que ha tocado campanas toda la vida.*

*Y Mika aparece al pie de la escalera.*

NARRACIÓN: *Y aquí tengo que ser honesto contigo, porque llevo toda la ruta siéndolo.*

*No recuerdo el vestido.*

*Recuerdo el pelo recogido y un mechón suelto que se le iba a escapar en algún momento y siempre se le escapaba. Recuerdo que llevaba mi camiseta favorita debajo, porque me dijo que iba a llevar algo mío aunque nadie lo viera, y que lo dijo con esa cara de quien hace una travesura a los veintitrés años. Recuerdo que venía sola, sin nadie que la entregara, porque su familia era la que estaba en esa sala y ninguna otra.*

*Y recuerdo que llegó al centro, se paró delante de mí, y lo primero que hizo —lo primero, antes de que el alcalde abriera la boca, antes de todo— fue mirarme y comprobar, con alivio genuino, que yo seguía allí.*

MIKA: "Estás."

HIROSHI: "Estoy."

MIKA: "Vale. Es que no sabía."

HIROSHI: "Mika, llevo un año viviendo encima del mercado."

MIKA: "Ya. Pero es una boda. La gente huye de las bodas."

NARRACIÓN: *El pueblo se ríe. Yo también. Y a partir de ahí, la ceremonia es corta y fea y perfecta: el alcalde se lía con mi apellido dos veces, un niño de la segunda fila se pone a llorar por un caramelo, y en el momento de "sí, quiero" suena un móvil en la cocina y la Señora Tanaka sale corriendo con el delantal.*

*Y nadie se acordará de nada de eso.*

*O mentira: alguien sí. Porque en la tercera fila, muy quieta, con el móvil en el regazo y el dedo sobre el botón de grabar pero sin grabar, Saki mira a Mika con una expresión que no le había visto nunca. Saki, la que comprueba el peso de un pescado antes de comprarlo. Saki, la que llora en privado. Saki, que a las dos de la madrugada del último jueves me dijo, con la vista en la pared de la cocina, "si algún día te portas mal con ella, Hiroshi, no te voy a matar yo, te va a matar ella, pero yo lo voy a celebrar".*

*Saki no está grabando. Al final no graba.*

*Y esa, es la verdad de toda esta ruta: la mujer que podría grabar cualquier cosa, el día que más le importa, decide que hay cosas que solo se viven.*

*CG 13 — "Las cinco campanas".*

*CG 14 — "El sí".*

---

NARRACIÓN: *La comida dura cinco horas.*

*Saki ha hecho el menú: una sopa de miso que ya no es la del Capítulo 2 ni es la de su restaurante, sino otra cosa que nació en este taller un martes de invierno y que ahora mismo están comiendo ciento veinte personas en la calle. Hay cangrejo del puerto, hay siete tipos de encurtidos de la Señora Tanaka, hay un plato de pez de roca que no está en la carta de nadie y que Jiro se ha comido de pie junto a la ventana, solo, mirando el pueblo.*

*Y luego vienen los brindis, que es donde el pueblo se desmadra.*

*Primero la Señora Tanaka, que se sube a una silla con sesenta años de autoridad:*

SRA. TANAKA: "Yo conocí a este hombre el primer día. Entró en mi mercado con dos bolsas y una idea, y le dije que no vendría nadie, y aquí hay ciento veinte personas. Señor Matsuda: me equivoqué. Y no me alegro de equivocarme nunca."

*Luego Jiro, que no suelta discursos y esta vez suelta uno corto:*

JIRO: "Este edificio era de la familia Yamamoto. Se cerró cuando el pueblo empezó a morirse." *Levanta el vaso.* "Esta noche duerme gente dentro."

*Luego Ren, que se atasca a los quince segundos, dice "bueno, ya está, ya lo he dicho" y se sienta.*

*Y luego Yuki.*

*Y aquí, presta atención, porque esta escena es tuya.*

YUKI: "Voy a hablar rápido porque no sé hacer esto."

*Pausa. Se alisa el vestido con las dos manos.*

YUKI: "Cuando llegué al pueblo tenía dieciocho años y no sabía cocinar. Bueno, sabía, pero no podía. Hay una diferencia."

*Pausa.*

YUKI: "Mika fue la primera persona que me dijo que mi comida le gustaba. Y me lo dijo mintiendo, porque ese día la sopa estaba mal, y yo lo sabía, y ella lo sabía, y aun así me lo dijo, y me lo dijo tan fuerte que me lo creí." *Mira a Mika.* "Eres la persona más mentirosa y más buena que conozco. Y eres mi hermana mayor. Y ese es el orden en el que van las cosas."

NARRACIÓN: *Silencio. Y después un estruendo, porque a Mika Nakamura, la creadora de contenido con cuatro millones de seguidores, la mujer que ha hablado delante de una cámara mil veces, la acaban de dejar sin palabras delante de ciento veinte personas.*

*Mika se levanta, cruza la sala, abraza a Yuki sin decir nada, y le dice al oído algo que nadie oye. Yuki asiente una vez, muy seria, y luego se ríen las dos.*

*No sabemos qué se dijeron. Este es el único secreto que no voy a contar aquí. Algunos son de ellas.*

*CG 15 — "Las hermanas".*

---

NARRACIÓN: *A las ocho de la tarde se va la luz del día y queda la luz de la fiesta: las guirnaldas que colgaron los niños del pueblo, que se encendieron mal y parpadean, y las velas que trajo la panadera, y la bombilla desnuda del taller, la misma de la primera noche, que sigue colgando del mismo cable y que yo dejé a propósito sin cambiar.*

*La gente se va en oleadas. Primero los mayores, luego los niños dormidos en brazos, luego los jóvenes que se van al bar de la estación. A las once quedamos nosotros.*

*Los cinco.*

*La mesa grande está llena de platos sucios, copas a medias y servilletas arrugadas. Jiro se ha quedado dormido en una silla de la cocina. La Señora Watanabe se fue a las diez y media, muy digna, después de decirle a Saki "vas a tener lista de espera de tres meses antes de septiembre", que resultó ser una profecía exacta.*

*Saki recoge. Ren apila sillas. Yuki dobla manteles.*

MIKA: "Podéis dejarlo. Mañana lo hago yo."

SAKI: "Mañana es tu mañana. No vas a limpiar en tu mañana."

MIKA: "Ya, pero—"

SAKI: "Mika."

MIKA: "Vale."

NARRACIÓN: *Y se sienta en el borde de la mesa, con el vestido ya arrugado y los zapatos quitados desde hace cuatro horas, y mira a las tres, y luego a mí.*

MIKA: "¿Saben una cosa?"

REN: "Si es otra vez lo de la cámara te tiramos a los encurtidos."

MIKA: "Es peor."

REN: "Dilo."

MIKA: "No os vais a ir. ¿Verdad? Ninguna."

NARRACIÓN: *Y ahí se para el aire.*

*Porque es la única pregunta que Mika Nakamura no ha hecho nunca en voz alta desde el primer día. La ha dado por hecha durante un año entero. La ha construido por encima del miedo, cada día, sin mirar abajo.*

SAKI: *dejando un plato en la pila* "Tengo un restaurante a cien metros. ¿A dónde quieres que me vaya?"

REN: "Yo tengo la fragua ahí detrás. Y si me voy, ¿quién le hace cuchillos al pueblo?"

YUKI: "Yo... yo duermo arriba."

MIKA: "No es lo mismo."

SAKI: "¿El qué?"

MIKA: "Vivir aquí y quedarse." *Pausa.* "No es lo mismo."

NARRACIÓN: *Y entonces Saki hace lo que Saki hace en los momentos importantes, que es llegar, cruzarse de brazos delante de otra persona y decir la verdad sin adornos.*

SAKI: "Mika. Yo conozco a mucha gente que se ha ido. Mi tío se fue. Los Yamamoto se fueron. El chico que trabajaba para Watanabe se fue. Irse no es una decisión que se toma una vez: se toma cada mañana." *Señala la sala con la barbilla.* "Y estas tres, y yo, llevamos un año tomando la misma decisión cada mañana. Así que sí. Es lo mismo. Es exactamente lo mismo, solo que ya está decidido."

REN: "Eso. Lo que ha dicho."

YUKI: "Yo he dicho lo de dormir arriba."

REN: "Lo tuyo también."

NARRACIÓN: *Y Mika se ríe. Y se le escapa una lágrima, y luego otra, y luego llora delante de las cuatro como lloran las personas que ya han decidido que pueden llorar delante de alguien.*

*Yo no digo nada.*

*Esta escena no es mía. Yo solo estoy aquí, mirando a la mujer que elegí y a las tres que se quedaron, y entendiendo por fin —un año tarde, como entiendo todo— que el final feliz de esta ruta no fue una boda. Fue una pregunta que por fin se pudo hacer en voz alta.*

*CG 16 — "La mesa larga".*

*CG 16b — "Nadie se va".*

PRÓXIMO: Escena 14M.2 - "La Noche de Bodas"

---

## ESCENA 14M.2 - LA NOCHE DE BODAS (EXPLÍCITA)

NARRACIÓN: *Subimos las escaleras a las once y media, y por primera vez en un año la habitación de arriba del mercado no se llama habitación, se llama nuestra casa, aunque tenga la misma cama individual, el mismo escritorio simple y la misma ventana que da a la calle principal.*

*Y sí: sigue siendo una cama individual.*

MIKA: "Vamos a caernos."

HIROSHI: "Nos vamos a caer."

MIKA: "Ya nos caímos la otra vez."

HIROSHI: "Y salió bien."

MIKA: "Salimos con el culo en el suelo, Hiroshi."

HIROSHI: "Y salió bien."

NARRACIÓN: *Se ríe. Se pone a reírse sola, de pie en medio de la habitación, con el vestido todavía puesto y el pelo medio suelto, y se ríe hasta que tiene que apoyarse en el escritorio, y yo la miro reírse y pienso que si esta ruta tuviera un único fotograma, sería este: ella riéndose de lo mal que va todo, en la habitación más pequeña del pueblo, con la persona que eligió.*

*Y cuando deja de reírse, se quita el anillo, lo deja con cuidado en el escritorio, y me mira de otra manera.*

MIKA: "¿Puedo pedirte una cosa?"

HIROSHI: "Lo que quieras."

MIKA: "Esta noche no te guardes nada. Ni una broma. Ni una de esas frases que dices cuando algo te da vergüenza."

HIROSHI: "¿Y tú?"

MIKA: "Yo tampoco."

NARRACIÓN: *Le desabrocho el vestido por la espalda, botón a botón, y ella se queda quieta mientras bajo, sin prisa, deteniéndome en cada uno como si cada botón fuera un año entero. Cuando llego al último, el vestido se le resbala por los hombros y cae al suelo alrededor de sus pies, y ella sale de él con un paso, y se queda delante de mí en la misma ropa interior de siempre, la de todos los días, porque Mika Nakamura no ha comprado nada para esta noche y esa es la cosa más Mika del mundo.*

HIROSHI: "No has comprado nada."

MIKA: "No."

HIROSHI: "Bien."

MIKA: "¿Bien?"

HIROSHI: "Bien. Que no haya nada nuevo. Que sea tú."

NARRACIÓN: *Y ahí se le rompe la cara un poco, en el buen sentido, y me besa ella a mí esta vez, con las dos manos en mi cara y todo el peso del cuerpo hacia delante, y nos vamos hacia la cama y nos caemos, y salió bien.*

*Le quito el sujetador con una mano y el resto con la otra, y ella me ayuda con mi camisa tirando de ella hacia arriba mientras yo intento quitarme los pantalones y ninguno de los dos tiene espacio, y hay un momento de codos y riñas y "espera, espera, que me engancho" que no está en ninguna tarjeta postal y que es exactamente lo que es acostarse con alguien a quien quieres.*

MIKA: "Esto de las bodas está muy idealizado."

HIROSHI: "Cállate y ven."

MIKA: "Muy romántico."

HIROSHI: "Mika."

MIKA: "Ya voy."

NARRACIÓN: *Y luego sí, luego deja de hablar.*

*La abrazo entera, con las dos manos en su espalda, y la siento entera contra mí: la piel cálida de los hombros, las costillas que se le mueven al respirar, la cicatriz diminuta sobre la clavícula que ya conozco de memoria, el peso de su muslo sobre el mío. La beso en el cuello y ella echa la cabeza hacia atrás y me deja el cuello a la vista como quien entrega una llave.*

*Bajo por el esternón, despacio, con la boca, deteniéndome donde sé que se le corta la respiración, y lo confirmo: se le corta en el mismo sitio que la primera vez y en el mismo sitio que la segunda, y hay algo insoportablemente bueno en conocer ya su mapa.*

MIKA: "Ahí."

HIROSHI: "¿Ahí?"

MIKA: "Ahí, sí. No pares."

NARRACIÓN: *No paro.*

*Le tomo un pecho en la mano y la siento arquearse, y ella me agarra del pelo con una mano y con la otra se clava las uñas en la palma, y le bajo la última prenda despacio, pasando por la cadera, hasta que la deja caer al suelo con el pie, y me quedo un momento mirándola entera, desnuda sobre una cama individual en una habitación de quince metros cuadrados, y ella no se tapa y no bromea y me sostiene la mirada.*

MIKA: "¿Qué?"

HIROSHI: "Nada."

MIKA: "Dilo."

HIROSHI: "Que llevo un año pensando que esto no me iba a pasar a mí."

MIKA: "¿Y?"

HIROSHI: "Y me está pasando."

NARRACIÓN: *Bajo la mano por su vientre, despacio —por su vientre de casi seis meses, redondo y tibio bajo la palma, que en este último año se ha convertido en el centro de gravedad de toda la casa—, y ella ya está esperándome, y cuando la toco se le escapa primero un aire corto y después un sonido que se muerde para no hacerlo, y yo le retiro la mano un segundo solo para que me mire.*

HIROSHI: "Dime si quieres parar."

MIKA: "Eso ya lo hemos hablado."

HIROSHI: "Dímelo igual."

MIKA: *con los ojos cerrados, con una sonrisa* "No quiero parar. No quiero parar, no quiero parar, no quiero parar."

NARRACIÓN: *Y la toco despacio, con dos dedos, en círculos, moviéndome por la forma en que se le tensa el muslo, y ella me busca la boca con la suya y luego se aparta para respirar, y me coge la muñeca y la guía y luego me la aprieta y luego se le olvida apretarla.*

*Y hay una cosa que no estaba en ninguna de las otras noches, y es que ya no somos dos. Lo digo en el sentido más literal del mundo: cada vez que ella se arquea, la curva de su vientre se mueve con ella, y yo tengo la mano libre apoyada ahí, abierta, sin apretar, como se apoya la mano en una puerta que no se quiere empujar. Y en mitad de todo, muy abajo, muy suave, se siente un movimiento que no es suyo ni mío. Un empujón diminuto, como un pez girando en el agua.*

MIKA: *con la respiración cortada, riéndose a medias* "Ay. Ay, no. Ahora no."

HIROSHI: "¿Qué?"

MIKA: "Que está despierta." *Y se le escapa una risa que la obliga a parar del todo, con la frente en mi hombro y los dos temblando de otra cosa.* "Se ha despertado. Tiene un sentido del humor horrible. Igual que su padre."

HIROSHI: "Igual que su madre, dirás."

MIKA: "Su madre es maravillosa."

HIROSHI: "Su madre está aquí encima, diciendo que no pare y que pare a la vez."

MIKA: "Es un don. Lo heredará."

NARRACIÓN: *Y nos quedamos quietos un momento, los dos, con mi mano en su vientre, esperando a ver si vuelve a moverse. No se mueve. Se queda tranquila, como si hubiera dicho lo que tenía que decir, y Mika suspira y me coge la cara con las dos manos y me la acerca hasta que las narices se nos tocan.*

MIKA: "¿Sabes qué es lo raro?"

HIROSHI: "Dime."

MIKA: "Que llevo toda la vida grabando. Toda. Y lo único que de verdad me ha pasado —esto, ahora, los tres— no hay ninguna cámara del mundo que lo pueda enseñar como es."

*Y cuando empieza a temblarle todo, y a poner la espalda en arco contra la sábana, y a decir mi nombre de esa forma corta y sin aire que ya me sé, se detiene de golpe.*

MIKA: "Espera."

HIROSHI: "¿Qué?"

MIKA: "No. Así no. Quiero... quiero verte."

NARRACIÓN: *Se incorpora, me empuja despacio por el pecho hasta que me sienta en el borde de la cama, se sube encima de mí a horcajadas, y por un momento se queda así, quieta, con las manos apoyadas en mis hombros, mirándome desde arriba con una seriedad que no le había visto nunca.*

MIKA: "Dime que no te vas a ir."

HIROSHI: "No me voy a ir."

MIKA: "Dime que mañana también."

HIROSHI: "Mañana también."

MIKA: "Y el martes."

HIROSHI: "Y todos los martes."

NARRACIÓN: *Y entonces sí baja, despacio, y los dos nos quedamos parados un instante sin respirar, ella con la frente apoyada en la mía y las dos manos en mi nuca, y luego empieza a moverse, al principio buscando, torpe, y luego encontrando, y yo la sostengo por la cadera y le levanto el peso y ella me muerde el hombro para no gritar y me agarra con las dos manos y todo el pelo suelto se le cae sobre la cara.*

MIKA: *en un susurro roto contra mi cuello* "Te quiero."

HIROSHI: "Te quiero."

MIKA: "No es un 'te quiero' de los que se dicen."

HIROSHI: "Lo sé."

MIKA: "Es el de verdad."

HIROSHI: "Lo sé."

NARRACIÓN: *Y se mueve más rápido y a mí se me acaba la conversación, y la sostengo fuerte con los dos brazos porque esta cama va a tirarnos al suelo otra vez y no pienso permitirlo, y ella llega antes que yo con un temblor largo que le recorre la espalda entera y que me clava las uñas en los omóplatos, y yo la sigo un instante después, sin ninguna elegancia, con la cara metida en su pelo.*

*Y nos quedamos así, despiertos, respirando, con los dos pegados y sudados y ridículos sobre una cama que no es de dos.*

MIKA: "Ha sido mejor que la primera vez."

HIROSHI: "Mucho mejor."

MIKA: "¿La primera fue mala?"

HIROSHI: "La primera fue la primera. Y tú te pusiste a llorar."

MIKA: "¡Lloré de emoción!"

HIROSHI: "Lloraste porque se me cayó el vaso."

MIKA: "Fue un vaso muy simbólico."

NARRACIÓN: *Y ahí nos reímos y nos desenredamos y ella se tumba atravesada, con los pies en la pared y la cabeza colgando del borde, y yo me quedo mirando el techo con una pierna fuera de la sábana.*

*Y en el silencio, con la ventana abierta y el pueblo absolutamente quieto, ella dice la última frase de esta ruta sin saber que lo es.*

MIKA: "Oye."

HIROSHI: "Dime."

MIKA: "Nadie nos ha visto."

*Pausa.*

MIKA: "Todo esto. La boda, la cena, las campanas. Y ahora. Nadie nos ha visto."

HIROSHI: "Sí."

MIKA: "Qué raro, ¿no? Que lo mejor de mi vida sea la única cosa que no he grabado."

NARRACIÓN: *Y se gira, se pone de lado, me busca la mano y la encuentra, y la aprieta.*

MIKA: "Sin cámara."

HIROSHI: "Sin cámara."

MIKA: "Para siempre."

PRÓXIMO: Escena 14M.3 - "El Estado del Mundo"

---

## ESCENA 14M.3 - EL ESTADO DEL MUNDO

NARRACIÓN: *Tres años después. Y como en todas las historias que se acaban bien, lo importante no es lo que pasó, sino lo que sigue pasando cuando ya nadie mira.*

*El pueblo tiene cuatrocientos doce habitantes. Cuando llegué tenía trescientos noventa y uno. No es una explosión demográfica: es que nadie se ha muerto sin sustituto y han vuelto siete familias jóvenes, y eso, en un pueblo de montaña, es una revolución silenciosa.*

*El taller es el mismo taller. Las ventanas grandes, los pisos de madera, la mesa larga. La bombilla desnuda sigue colgando del mismo cable, y he decidido que no la voy a cambiar nunca, ni cuando se funda, porque hay cosas que no se tocan.*

*Mika tiene veintiséis años, dirige el **Estudio Sakura** —la productora comunitaria del pueblo— y tiene tres empleados. Filma bodas, recetas de abuelas, nacimientos y una serie de documentales cortos sobre oficios que se estaban perdiendo: el último zapatero, la tejadora de redes, el afilador. Todo "con permiso, con crédito, con amor", que es el eslogan que ella escribió en la pared con rotulador y que nadie ha borrado.*

*Su canal tiene noventa mil seguidores. Un día tuvo cuatro millones.*

MIKA: "¿Sabes qué es lo mejor de tener noventa mil?"

HIROSHI: "¿Qué?"

MIKA: "Que puedo leer los comentarios."

NARRACIÓN: *Yuki tiene veintiún años, terminó sus estudios con las mejores notas de su promoción, y da clases los sábados por la mañana en el taller: doce alumnos, lista de espera de dos meses, y una manera de corregir un corte de verdura que da miedo. Sigue viviendo en la habitación de arriba del taller, que ahora es el tercer piso porque compramos la casa de al lado. Sigue sin pareja, y cuando alguien del pueblo le pregunta, contesta lo mismo: "Tengo cosas que hacer".*

*Va a ser chef. No hay ninguna duda. Cuando entra en una cocina, la cocina se ordena sola.*

*Ren tiene veinticinco años y dirige la fragua que abrió detrás del taller. Forja cuchillos, aperos, bisagras, y las cinco campanas que ya son siete. Cada cuchillo del pueblo —cada uno, del pescadero al alcalde— ha pasado por sus manos, y en cada uno hay una firma diminuta que casi nadie ve: una R y una media luna.*

*Emi volvió una vez, hace dos años, a pedir perdón. No era una trampa. Ren la escuchó de pie, sin interrumpirla, y al final le dijo una sola frase: "Yo también estaba allí esa noche. Y también me lo voy a llevar toda la vida." Y luego le hizo un cuchillo. Emi vive en la ciudad y vuelve en agosto.*

*Saki tiene treinta y un años y el **Restaurante Yamamoto** tiene lista de espera de tres meses y una estrella que ella no pidió y que cuelga en la pared de la cocina, donde solo la ve ella. Tiene dos aprendices, una de ellas la hija del pescadero, y ha empezado a escribir en un cuaderno grande las recetas que su tío se llevó cuando se fue. Volvió una vez, su tío. No para quedarse. Para comer.*

*A la Señora Tanaka le han puesto su nombre a la plaza del mercado. Ella dice que es una tontería y va todos los días a sentarse en el banco del centro.*

*Jiro murió el invierno pasado, en su casa, a los ochenta y nueve años, dormido. En el funeral, Mika filmó. Lo decidió él, dos semanas antes, con una claridad que dejó a todos sin palabras: "Grábalo, niña. Que el pueblo se acuerde de que yo estuve."*

*Lo grabó. Y esa grabación está en el archivo del Estudio Sakura, con una etiqueta que dice: "Jiro. Para el pueblo."*

*Nadie la ha subido nunca. Es de todos y no es de nadie.*

NARRACIÓN: *Y en la cocina del taller, en el mismo gancho donde lleva un año, sigue el cuchillo de Kenji.*

## ESCENA 14M.4 - LA PARADA DEL AUTOBÚS

NARRACIÓN: *Es martes. Eso lo sé porque los martes el autobús llega a las 4:40 y los martes hay una sola persona esperándolo, y esa persona soy yo, y no porque espere a nadie: porque me gusta ver llegar el autobús.*

*Lo he hecho todas las semanas desde hace un año. Mika dice que es una costumbre rara. Yo creo que es una manera de acordarse.*

*Y hoy, mientras el vehículo serpentea la última curva antes de entrar al valle, pienso —como pienso cada martes— en el día en que bajé de ese mismo autobús con dos bolsas y nada más. Con el miedo pegado a la espalda como una camiseta mojada.*

*El autobús exhala un suspiro mecánico mientras se detiene frente a la única parada de Sakura-machi.*

*El mismo suspiro. Exactamente el mismo. Hay sonidos que no se gastan.*

*Se abre la puerta con ese chirrido que solo tienen los autobuses de montaña, y baja un solo pasajero.*

*Es joven. Veintipocos. Lleva una maleta de ruedas y una mochila —dos bolsas, dos, que es exactamente lo que cabe de una vida cuando uno la deja atrás— y se queda parado en el arcén con la cara de quien esperaba otra cosa. Mira los carteles desgastados. Mira las fachadas. Mira la carretera por la que acaba de llegar.*

NARRACIÓN: *No sé quién es. No sé de dónde viene. No sé qué está buscando ni si se va a quedar.*

*Pero sé exactamente qué está sintiendo.*

CONDUCTOR: "¿Seguro que este es su destino, joven?"

JOVEN: "...Sí. Creo que sí."

CONDUCTOR: "El próximo autobús pasa en tres días. Por si cambia de opinión."

NARRACIÓN: *El autobús arranca y desaparece por la carretera serpenteante, llevándose con él el último lazo con la vida anterior de ese chico. Exactamente como se llevó el mío, hace cuatro años, un jueves.*

*Y entonces el chico se gira hacia la plaza, mirando alrededor como un animal que acaba de entrar en una habitación nueva, y se encuentra con la cosa más rara que hay en este pueblo.*

MIKA: "¿Está perdido, jovencito?"

NARRACIÓN: *Está sentada en el banco que instalaron frente al mercado —el que tiene la placa de "Plaza Hanako Sato" y donde la Señora Tanaka se sienta todas las mañanas a decir que la placa es una tontería—, con la cámara al hombro, la tapa quitada y el sol de la tarde dándole justo en la cara.*

*No lleva el uniforme de chef del origen de todo esto. Lleva una chaqueta de trabajo con manchas de revelado y un bolsillo lleno de tarjetas, y en la muñeca izquierda, junto al anillo que ya no se quita ni para amasar, lleva una de esas pulseras de tela que los pueblos regalan cuando quieren a alguien.*

*Y sonríe. Sonríe como la primera vez que la vi sonreír de verdad, la que no salía en ninguna cámara.*

JOVEN: "Eh... sí. Llegué... me dijeron que aquí había un taller. Un taller de cocina."

MIKA: "Ajá."

JOVEN: "¿Es aquí? ¿Sakura-machi?"

MIKA: "Estás en la plaza. Sakura-machi es lo que se ve desde aquí." *Baja la cámara y señala con el mentón, en círculo, sin prisa:* "Eso de ahí es el mercado. Eso es la fragua. Eso, el restaurante. Y donde hay luz encendida a las cinco de la mañana, aunque sea martes, es el taller."

NARRACIÓN: *El chico mira hacia donde apunta. Y cuando la ve —la fachada de madera de dos pisos, las ventanas grandes, la puerta entreabierta con el olor saliendo— se le cambia la cara. Se le ordena. Es la misma cara que tenía yo.*

JOVEN: "¿Y quién...?"

MIKA: "¿Quién manda?"

JOVEN: "Quién enseña."

NARRACIÓN: *Mika se levanta. Se echa la cámara al hombro como quien se echa una chaqueta, y empieza a caminar despacio hacia el taller. El chico no se mueve. Y ella se gira a medio camino y le hace con la mano ese gesto universal de "¿vienes o qué?".*

MIKA: "Se llama Hiroshi. Matsuda."

JOVEN: "¿Es bueno?"

MIKA: "¿Bueno cocinando?"

MIKA: "Bueno, es mi marido, así que voy a decir que sí con toda la imparcialidad del mundo."

---

## ESCENA 14M.5 - LA PUERTA ABIERTA

NARRACIÓN: *Y ahí, desde la puerta del taller, sin querer, me río. Se me escapa. Porque llevo cuatro años escuchando esa broma y sigue sin gastarse, y porque desde aquí, a doce metros, la veo caminar con la cámara al hombro y sigo sin entender cómo pude tener miedo alguna vez de esta mujer.*

*Salgo a la calle con el delantal puesto y los brazos manchados de harina.*

HIROSHI: "¿Vas a traerme clientes o a asustarlos?"

MIKA: "Le estaba explicando el pueblo."

HIROSHI: "Le estabas explicando el pueblo con comentario incluido."

MIKA: "El comentario es la mejor parte."

NARRACIÓN: *El chico nos mira alternativamente, sin entender nada, con las dos bolsas en las manos y esa cara de quien acaba de bajarse de un autobús y no sabe si ha llegado a un sitio o a una trampa.*

*Lo entiendo. Yo tuve esa cara.*

*Y me pongo en la puerta, apoyado en el marco, y le hago la única pregunta que importa. La misma que me habría gustado que me hicieran a mí en aquel entonces, en lugar de mirarme como a un bicho.*

HIROSHI: "Depende."

JOVEN: "¿De qué?"

HIROSHI: "De si traes planes. Porque aquí venimos a cocinar, muchacho, pero lo que se cocina después no lo decide nadie más que tú."

NARRACIÓN: *El chico traga. Se le mueven las manos, apretando las asas de las bolsas. Y entonces dice las dos palabras que decidieron mi vida, y que estoy bastante seguro de que van a decidir la suya.*

JOVEN: "Sí. Traigo planes."

NARRACIÓN: *Mika se me acerca, se pone a mi lado, y me apoya la barbilla en el hombro.*

MIKA: "¿Te recuerda a alguien?"

HIROSHI: "A un tipo bastante tonto que llegó con dos bolsas y sin saber hacer sopa."

MIKA: "Tú sabías hacer sopa."

HIROSHI: "Sabía hacer sopa de restaurante. No es lo mismo."

NARRACIÓN: *Y le hacemos sitio. Igual que me lo hicieron a mí.*

*La Señora Tanaka, desde el banco de su plaza, levanta una mano saludando al recién llegado sin saber quién es. En el taller, cuatro campanas de plata cuelgan de la viga, cada una con su sonido distinto, y la quinta —la que Ren añadió el año pasado— tiene un vibrado más grave porque Ren decidió que ya éramos más.*

*Y en la cocina, sobre la mesa grande, hay una olla con algo que huele a casa.*

*Eso siempre es lo primero que hago con quien llega. Antes de la matrícula, antes del papeleo, antes de las reglas: darle de comer.*

*Porque así me recibieron a mí.*

*Y porque es la única manera que conozco de decir "quédate" sin pedirlo.*

MIKA: "Entra."

NARRACIÓN: *Dice Mika, y le abre la puerta con la cadera, porque tiene las manos ocupadas con la cámara.*

*Y el chico entra.*

*Y yo entro detrás.*

*Y por un momento —solo un momento—, en el vano de la puerta, con las ventanas grandes encendidas de luz naranja y el pueblo entero respirando detrás de nosotros, me giro y miro la parada del autobús, vacía.*

*El mismo sitio donde hace cuatro años me bajé yo sin imaginar que no volvería a subirme nunca.*

*Ahí sigue el cartel desgastado. Ahí sigue el banco. Ahí sigue todo.*

*Y ya no me da lástima.*

*Cosas de las historias que terminan bien: los sitios donde estuvimos mal se quedan ahí, con su placa y su banco y su cartel viejo, pero dejan de pesar. Se convierten en el marco de lo que vino después.*

*Cierro la puerta.*

*Y el olor a sopa llena la casa otra vez.*

`[CRÉDITOS]`

---

## ESCENA POST-CRÉDITOS - LA FOTO

NARRACIÓN: *La cámara está en el trípode, en el centro de la mesa larga, con el temporizador encendido y la lucecita roja parpadeando. Una luz roja. La misma que hace cuatro años daba miedo, y ahora da igual.*

*Porque esta vez la cámara no está para vender nada: está puesta por una persona a la que le han dado permiso para grabar.*

*Y sobre el aparador, junto a la pared del dibujo, en la cuna de mimbre que Ren hizo con la primera madera que compró para su casa, duerme la sexta.*

*Hina. Cinco meses. Nació en septiembre, con el pueblo entero esperando en la puerta y la Señora Tanaka organizando turnos de visita en una libreta, como si fuera un festival.*

*Mika decidió el nombre sola, en una tarde, y me lo dijo así: "No la voy a llamar Akari. Akari ya tuvo su vida. Esta tiene que tener la suya." Y luego se quedó callada un rato y añadió: "Pero le voy a contar quién fue. Eso sí."*

*Los cinco nos apretamos donde no cabemos. Ren con el delantal de la fragua, la manga arremangada y una quemadura nueva en el antebrazo. Saki con el pelo recogido y una cuchara de madera que se niega a soltar. Yuki en el centro, delante de todos, con las manos manchadas de zumo de algo, riéndose de algo que ya no va a salir en la foto. Mika saltando del banco y cruzando delante del objetivo, gritando "¡que no he salido, que no he salido!"*

*Y yo detrás de todos, el más viejo de la cuadrilla con cuarenta y un años, con una mano en el hombro de Yuki y la otra colgando, sin saber qué hacer con ella, como en todas las fotos de mi vida.*

MIKA: "¡Tres!"

*Tres.*

MIKA: "¡Dos!"

*Dos.*

*Y en el uno, Mika se lanza y se mete bajo mi brazo justo antes del clic, y la campana quinta vibra porque alguien choca contra la viga.*

*Clic.*

*CG FINAL — "Familia Culinaria".*

NARRACIÓN: *En la pared del fondo, detrás de nosotros, cuelga el dibujo grande: un pueblo pequeño, con casas y chimeneas y una carretera serpenteante, hecho a bolígrafo por una niña de doce años que nunca llegó a verlo.*

*Y en la esquina inferior, en un rincón discreto, la fotografía original: la fotografía de la hermana de Mika, enmarcada por fin, junto al dibujo que hizo porque "este pueblo merece existir".*

*Los dos están en la foto. En el fondo. Como están los que ya no están: en el fondo y en todo.*

*Y esa —no la del festival, no la del estreno, no la de ningún móvil— es la imagen con la que se acaba esta historia.*

*Un plano de cinco personas que no están seguras de dónde ponerse.*

*Nadie mirando a la cámara. Nadie grabando.*

*Sin cámara.*

*Para siempre.*

`FIN DE LA RUTA MIKA`

---

## ESTABLECIDO EN ESTE CAPÍTULO

- Boda de Hiroshi y Mika en el taller, un año después del compromiso (14M.1). Las cuatro campanas de plata de la familia Yamamoto suenan al entrar la novia (cierre del objeto de 20.9).
- Rol del quinteto: Ren de testigo, Saki de caterer, Yuki de dama de honor (18 años, rol de hermana menor — sin romance en esta rama).
- Noche de bodas: tercera y última escena explícita de la ruta, cierre del lema "Sin cámara. Para siempre." (14M.2).
- Estado del mundo tres años después: Estudio Sakura (Mika, 26, productora comunitaria, 90k seguidores, 3 empleados); Yuki (21) da clases los sábados y tiene su futuro propio; Ren (25) dirige la fragua; Saki (31) tiene el Restaurante Yamamoto con estrella y lista de espera de tres meses; plaza "Hanako Sato"; muere Jiro a los 89 y Mika lo filma por decisión suya (14M.3).
- Final definitivo: el autobús de las 4:40 trae a un joven con dos bolsas; Mika ocupa el lugar de la anciana del bastón del Cap. 1.1 y le dice la frase espejo; Hiroshi le ofrece la misma acogida que él recibió (14M.4–14M.5).
- Escena post-créditos: la foto familiar, con el dibujo de la hermana de Mika y su fotografía enmarcada en el fondo. El cuchillo de Kenji (mentor) sigue en su gancho.

## TONO ESTABLECIDO

- Cierre circular absoluto con el Cap. 1.1 (plano espejo de la parada) y con la tesis de la ruta ("nadie nos ha visto").
- Duelo integrado, no superado: la hermana de Mika y el mentor Kenji están presentes en la última imagen sin dramatismo.
- Registro final: sereno, sin épica. La felicidad como rutina, no como premio.
- Última frase de la ruta, textual: **"Sin cámara. Para siempre."**

## ELEMENTOS CLAVE

- **Cierre de todos los cabos registrados en `routes/ruta-mika.md` §5** (hermana de Mika, amenazas de los cuatro antagonistas, amenaza legal contra Saki, parentesco Yamamoto, arco de Yuki/Matsui, Ren/Emi, culpa de Hiroshi y destino del chef que lo reemplazó).
- **Los tres misterios que NO se inventan** quedan cerrados emocionalmente pero `NOT STATED` como dato factual: muerte de Kenji (mentor), accidente del abuelo de Ren y veracidad de Matsui sobre la madre de Yuki.
- **Meta final desbloqueado:** "El Corazón Auténtico" (final único — no existen finales neutros ni malos en esta ruta).
- **Galería completa:** 17 CGs, escalera suave→medio→explícito, con 3 escenas explícitas sin elipsis (11M.4, 13M.5, 14M.2).

## PRÓXIMO

FIN DE LA RUTA MIKA. No continuar más allá de 14M.4 sin nueva orden del autor (epílogos-hijo o rutas A/B/D serían expansiones separadas).





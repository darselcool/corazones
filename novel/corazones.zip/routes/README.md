# RUTAS — Índice de ramas (guion desarrollado)

> Índice de los guiones prosificados de *Corazones en Ebullición*. El diseño de producción vive en `../routes.md`; aquí está el texto de juego.

## Estructura

| Rama | Carpeta / archivo | Cobertura | Estado |
|---|---|---|---|
| **Ruta Común** (tronco) | `ruta-comun/` | Caps. 1–21 (llegada de Hiroshi → bifurcación del Cap. 21) | **Completa** (31,083 palabras) |
| **Ruta Harem** | (canon del texto original) | Caps. 9H–15H | Completa en `../_source-extract.md` / XML original |
| **Ruta Mika** (Individual C) | `ruta-mika/` | Caps. 8M–14M + opcionales + epílogo | **Completa** (~52,700 palabras) |
| Ruta A — Saki | — | — | `NOT STATED` |
| Ruta B — Ren | — | — | `NOT STATED` |
| Ruta D — Yuki | — | — | `NOT STATED` |

## Orden de lectura

1. `ruta-comun/capitulo-01.md` … `capitulo-21.md` (tronco común, voz de Hiroshi en primera persona).
2. Bifurcación (Escena 21.5, elección A–E).
3. Según la elección: `ruta-mika/` (Opción C) o la Ruta Harem (Opción E, caps. 9H+).

## Reglas aplicadas al guion

- **Fidelidad al canon**: la ruta común reproduce el texto original; no se inventó material narrativo.
- **Voz narrativa**: narración siempre en **primera persona desde la mente del protagonista** (Hiroshi Matsuda); sin vocativos meta-narrativos.
- **El sistema de puntos termina al entrar en cualquier ruta** (decisión de autor, 14/09/2026).
- Los diseños de las ramas A/B/D están pendientes de definición de autor (cada una con final único feliz y mínimo 2 escenas explícitas).

Ver `../canon-rules.md` para las reglas de canon y etiquetas de certeza.
